<link rel="stylesheet" href="/assets/css/css_sidebar.css">
<div class="sidebar_content">
    <div class="sidebar_box">
        <div class="box_heading">
            <a href="#">Bạn Có Biết ?</a>
        </div>
        <div class="box_content_sidebar">
            <ul>
                <li class="item_content_sidebar">
                    <img class="icon_li" src="/images/icons8-star-50.png" alt="icon" width="13px" height="13px">
                    Game Bắn Súng
                    <strong>
                        <a href="/csgo/">CSGO</a>
                    </strong>
                </li>
                <li class="item_content_sidebar">
                    <img class="icon_li" src="/images/icons8-star-50.png" alt="icon" width="13px" height="13px">
                    Khám Phá
                    <strong>
                        <a href="/pubg/">PUBG</a>
                    </strong>
                    Phiên Bản Mới
                </li>
                <li class="item_content_sidebar">
                    <img class="icon_li" src="/images/icons8-star-50.png" alt="icon" width="13px" height="13px">
                    Bóng Đá
                    <strong>
                        <a href="/fifa-online-4/">Fifa Online 4</a>
                    </strong>
                    Đỉnh Cao
                </li>
                <li class="item_content_sidebar">
                    <img class="icon_li" src="/images/icons8-star-50.png" alt="icon" width="13px" height="13px">
                    Garena
                    <strong>
                        <a href="/lien-quan-mobile/">Liên Quân Mobile</a>
                    </strong>
                </li>
                <li class="item_content_sidebar">
                    <img class="icon_li" src="/images/icons8-star-50.png" alt="icon" width="13px" height="13px">
                    Khám Phá
                    <strong>
                        <a href="/lien-minh-huyen-thoai/">LMHT</a>
                    </strong>
                    Việt Nam
                </li>
                <li class="item_content_sidebar">
                    <img class="icon_li" src="/images/icons8-star-50.png" alt="icon" width="13px" height="13px">
                    News
                    <strong>
                        <a href="/valorant/">Valorant</a>
                    </strong>
                    Riot Games
                </li>
            </ul>
        </div>
    </div>
    <div class="sidebar_box_gray">
        <div class="box_linkout">
            <p>Liên Kết Hữu Ích</p>
        </div>
        <div class="box_content_links">
            <ul>
                <li class="item_content_link">
                    Gaming Philippines
                    <a rel="dofollow" target="_blank" href="https://tobet88.tips/"><b>TOBET88</b></a>
                </li>
                <li class="item_content_link">
                    <a rel="dofollow" target="_blank" href="https://shlive1.tv" ><b>https://shlive1.tv</b></a>
                </li>
                <li class="item_content_link">Link vào
                    <a rel="dofollow" target="_blank" href="https://linkvaobk8.club/" ><b> BK8</b></a>
                </li>
                <li class="item_content_link">
                    <a target="_blank" rel="dofollow" href="https://socg.org/"><b>xôi lạc tv</b></a>
                </li>
                <li class="item_content_link">
                    <a target="_blank" rel="dofollow" href="https://www.newcastlediamonds.co/"><b>xoilac tv trực tiếp bóng
                            đá</b></a>
                </li>
                <li class="item_content_link">
                    <a target="_blank" rel="dofollow" href="https://www.cakhia-tv.io/"><b>cakhia tv trực tiếp bóng
                            đá</b></a>
                </li>
                <li class="item_content_link">
                    <a target="_blank" rel="dofollow" href="https://maggievalleynclife.com/"><b>Socolive trực tiếp</b></a>
                </li>
                <li class="item_content_link">
                    <a target="_blank" rel="dofollow" href="https://tf88pow.com/"><b>TF88</b></a>
                </li>
                <li class="item_content_link">
                    <a target="_blank" rel="dofollow" href="https://www.jun8887.com/?uagt=guanggao5a&path=signup"><b>Jun88city.net</b></a>
                </li>
                <li class="item_content_link">
                    <a target="_blank" rel="dofollow" href="https://unge.education/"><b>Rakhoi tv</b></a>
                </li>
                <li class="item_content_link">
                    <a target="_blank" rel="dofollow" href="https://socolivetv.ceo/"><b>Socolive tv</b></a>
                </li>
                <li class="item_content_link">
                    <a rel="dofollow" target="_blank" href="https://webnhacaiuytin.info"><b>Nhà cái uy tín</b></a>
                </li>
                <li class="item_content_link">
                    <a rel="dofollow" target="_blank" href="https://iwinclubb.com/"><b>iwin club</b></a>
                </li>  
                <li class="item_content_link">Trang chủ
                    <a rel="dofollow" target="_blank" href="https://128.199.129.138/" ><b> Ku11</b></a>
                </li>
                <li class="item_content_link">Trực tiếp
                    <a rel="dofollow" target="_blank" href="https://xoilaczza.tv/" ><b> Xoilac TV</b> chất lượng cao</a>
                </li>
                <li class="item_content_link">
                    <a rel="dofollow" target="_blank" href="https://mitomtv.tel/"  ><b>mitom</b></a>
                </li>
                <li class="item_content_link">
                    <a rel="dofollow" target="_blank" href="https://nohu777.co/"><b>Nohu</b></a>
                </li>
                <li class="item_content_link">
                    <a rel="dofollow" target="_blank" href="https://greenparkhadong.com/" ><b>xem bong da xoilac tv</b></a>
                </li>
                <li class="item_content_link">xem trực tiếp bóng đá 
                    <a rel="dofollow" target="_blank" href="https://anstad.com/" ><b> xoilac</b></a>
                </li>
                <li class="item_content_link">xem bóng đá
                    <a rel="dofollow" target="_blank" href="https://musical-theatre.net/" ><b> xoilac</b></a>
                </li>
                <li class="item_content_link">
                    <a rel="dofollow" target="_blank" href="https://phongkhamago.com/" ><b>xôi lạc tv trực tiếp bóng đá hôm nay</b></a>
                </li>
                <li class="item_content_link">
                    <a rel="dofollow" target="_blank" href="https://cultureandyouth.org/" ><b>xem bóng đá trực tuyến xoilac</b></a>
                </li>
                <li class="item_content_link">
                    <a rel="dofollow" target="_blank" href="https://taigamebai68.link/" ><b>68 game bài</b></a>
                </li>
                <li class="item_content_link">nhà cái
                    <a rel="dofollow" target="_blank" href="https://139.59.226.85/" ><b> Ku11</b></a>
                </li>
                <li class="item_content_link">
                    <a rel="dofollow" target="_blank" href="https://kubetmov.com/" ><b>Kubetmov.com</b></a>
                </li>
                <li class="item_content_link">Trang
                    <a rel="dofollow" target="_blank" href="https://15.235.196.8/" ><b> Kubet</b></a>
                </li>
                <li class="item_content_link">
                    <a rel="dofollow" target="_blank" href="https://15.235.143.112/" ><b> Kubet88</b></a>
                </li>
                <li class="item_content_link">
                    <a rel="dofollow" target="_blank" href="https://jun88.fashion/" ><b>jun88 tv</b></a>
                </li>
                <li class="item_content_link">link xem
                    <a rel="dofollow" target="_blank" href="https://ana-cooljapan.com/" ><b> bóng đá xôi lạc</b></a> tv hôm nay
                </li>
                <li class="item_content_link">
                    <a rel="dofollow" target="_blank" href="https://8day.at/" ><b>8day.at</b></a>
                </li>
                <li class="item_content_link">
                    <a rel="dofollow" target="_blank" href="https://win55.cloud" ><b>win55</b></a>
                </li>
                <li class="item_content_link">
                    <a rel="dofollow" target="_blank" href="https://789clubb.asia/" ><b>789club</b></a>
                </li>
                <li class="item_content_link">
                    <a rel="dofollow" target="_blank" href="https://33win.id/" ><b>33win</b></a>
                </li>
                <li class="item_content_link">
                    <a rel="dofollow" target="_blank" href="https://mb66.network/" ><b>Nhà cái MB66</b></a>
                </li>
                <li class="item_content_link">
                    <a rel="nofollow" target="_blank" href="https://ituoitho.com" ><b>Web chơi Game Online</b></a>
                </li>
                <li class="item_content_link">
                    <a rel="dofollow" target="_blank" href="https://b52game.makeup/" ><b>b52 club</b></a>
                </li>
                <li class="item_content_link">
                    <a rel="dofollow" target="_blank" href="https://helo88.lol/" ><b>Helo88</b></a>
                </li>
                <li class="item_content_link">
                    <a rel="dofollow" target="_blank" href="https://hi88chat.com" ><b>https://hi88chat.com/</b></a>
                </li>
                <li class="item_content_link">
                    <a rel="dofollow" target="_blank" href="https://sunwin.london" ><b>sunwin</b></a>
                </li>
                <li class="item_content_link">
                    <a rel="dofollow" target="_blank" href="https://xoso66.vin/" ><b>Xoso66</b></a>
                </li>
                <li class="item_content_link">
                    <a rel="dofollow" target="_blank" href="https://raybet.asia/" ><b>Raybet</b></a>
                </li>
                <li class="item_content_link">
                    <a rel="dofollow" target="_blank" href="https://mb66.news/" ><b>mb66.news</b></a>
                </li>
                <li class="item_content_link">
                    <a rel="dofollow" target="_blank" href="https://okvip.ing/" ><b>OKVIP</b></a>
                </li>
                <li class="item_content_link">
                    <a rel="dofollow" target="_blank" href="https://okvip.marketing/producer/https//nhacaiuytin.vision/" ><b>https//nhacaiuytin.vision/</b></a>
                </li>
                <li class="item_content_link">
                    <a rel="dofollow" target="_blank" href="https://qh88.download/" ><b>qh88</b></a>
                </li>
                <li class="item_content_link">
                    <a rel="dofollow" target="_blank" href="https://hi88.ist/" ><b>hi88</b></a>
                </li>
                <li class="item_content_link">
                    <a rel="dofollow" target="_blank" href="https://rikvip.xyz/" ><b>Rikvip</b></a>
                </li>
                <li class="item_content_link">
                    <a rel="dofollow" target="_blank" href="https://6686.ch/" ><b>6686bet</b></a>
                </li>
                <li class="item_content_link">
                    <a rel="dofollow" target="_blank" href="https://mb66.network/" ><b>Nhà cái MB66</b></a>
                </li>
                <li class="item_content_link">
                    <a rel="dofollow" target="_blank" href="https://kubet.boston/" ><b>kubet777</b></a>
                </li>
                <li class="item_content_link">
                    <a rel="dofollow" target="_blank" href="https://fun88.fan/" ><b>fun88</b></a>
                </li>
                <li class="item_content_link">
                    <a rel="dofollow" target="_blank" href="https://xoilactv.pe/" ><b>xôi lạc tv</b></a>
                </li>
            </ul>
        </div>
    </div>
    <div class="hot_news">
        <div class="box_heading">
            <a href="#">
                <img src="/images/icons8-fire-30.png" alt="icon"   width="22px" height="22px">
                Tin Mới Nóng
            </a>
        </div>
        <div class="box_content_sidebar">
            <ul>
                <?php foreach ($blog_new as $key => $val) { ?>
                    <li class="item_hot_news">
                        <a href="/<?= $val['alias'] ?><?= ($val['id'] > 1024) ? '' : '/' ?>">
                            <?= $val['title'] ?>
                        </a>
                    </li>
                <?php } ?>
            </ul>
            <div class="see_more_news">
                <div class="btn_see_more">
                    <a href="/">Xem thêm tin mới nhất Vnesports</a>
                </div>
            </div>
        </div>
    </div>
</div>