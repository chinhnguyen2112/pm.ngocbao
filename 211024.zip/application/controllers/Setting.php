<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Setting extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Madmin');
        $this->load->database();
        $this->load->helper(['url', 'func_helper', 'images']);
        $this->load->library(['session', 'pagination311', 'upload']);
        if (admin()) {
            $g_admin = $this->Madmin->get_by(['id' => $_SESSION['user']['id'], 'delete_user' => 0], 'users');
            $this->session->set_userdata('user', $g_admin);
        } else {
            redirect('/dang-nhap/');
        }
    }
    public function project_type()
    {
        if (check_role() == 5 || check_role() == 4 || check_role() == 3 || check_role() == 0) {
            set_status_header(404);
            return $this->load->view('errors/html/error_role');
        } else {
            $page = $this->uri->segment(2);
            if ($page < 1 || $page == '') {
                $page = 1;
            }
            $limit = 10;
            $start = $limit * ($page - 1);
            $where = "AND project_type.id > 0 ";
            if ($this->input->get('n') != '') {
                $n = $this->input->get('n');
                $where .= " AND project_type.name LIKE '$n'";
            }
            if ($this->input->get('au') != '') {
                $au = $this->input->get('au');
                $where .= " AND project_type.author = $au";
            }
            if ($this->input->get('type') != '') {
                $type = $this->input->get('type');
                $where .= " AND project_type.status = $type";
            }
            if ($this->input->get('cs') > 0) {
                $created_start = $this->input->get('cs');
                $where .= " AND project_type.created_at >= $created_start";
            }
            if ($this->input->get('ce') > 0) {
                $created_end = $this->input->get('ce');
                $where .= " AND project_type.created_at <= $created_end";
            }
            $project_types =  $this->Madmin->query_sql("SELECT project_type.*,users.name as name_author  FROM project_type JOIN users ON users.id=project_type.author WHERE delete_status = 0 $where");
            pagination('/loai-du-an/', count($project_types), $limit);
            $project_types_limit =  $this->Madmin->query_sql("SELECT project_type.*,users.name as name_author  FROM project_type JOIN users ON users.id=project_type.author WHERE delete_status = 0 $where LIMIT $start,$limit");
            $data['list'] = $project_types_limit;
            $data['name'] = $this->Madmin->query_sql("SELECT DISTINCT name FROM project_type WHERE delete_status = 0  ORDER BY name ASC");
            $data['author'] = $this->Madmin->query_sql("SELECT id,name,role  FROM users WHERE role = 1 OR role = 2  ORDER BY name ASC");
            $data['canonical'] = base_url('laoi-du-an/');
            $data['meta_title'] = 'Loại dự án';
            $data['content'] = 'setting/project_type';
            $data['list_js'] = [
                'sweetalert.min.js',
                'jquery.validate.min.js',
                'setting/project_type.js',
            ];
            $data['list_css'] = [
                'sweetalert.css',
                'setting/project_type.css',
            ];
            return $this->load->view('index', $data);
        }
    }
    public function add_project_type()
    {
        if (check_role() == 5 || check_role() == 4 || check_role() == 3 || check_role() == 0) {
            $response = [
                'status' => 0,
                'msg' => 'Không có quyền thao tác'
            ];
        } else {
            $id = $this->input->post('id');
            $data['name'] = $name =  $this->input->post('name');
            $data['price'] =  $this->input->post('price');
            $data['status'] = $this->input->post('status');
            $data['updated_at'] = time();
            $where = [
                'name' => $name,
                'delete_status' => 0
            ];
            if ($id > 0) {
                $where['id !='] = $id;
            }
            $check = $this->Madmin->get_by($where, 'project_type');
            if ($check == null) {
                if ($id > 0) {
                    $insert = $this->Madmin->update(['id' => $id], $data, 'project_type');
                } else {
                    $data['author'] = $_SESSION['user']['id'];
                    $data['created_at'] = time();
                    $insert = $this->Madmin->insert($data, 'project_type');
                }
                $response = [
                    'status' => 1,
                    'msg' => 'Thành công'
                ];
            } else {
                $response = [
                    'status' => 0,
                    'msg' => 'Tên loại dự án đã tồn tại'
                ];
            }
        }
        echo json_encode($response);
    }
    public function change_project_type()
    {
        if (check_role() == 5 || check_role() == 4 || check_role() == 3 || check_role() == 0) {
            $response = [
                'status' => 0,
                'msg' => 'Không có quyền thao tác'
            ];
        } else {
            $id =  $this->input->post('id');
            $name =  $this->input->post('name');
            $data[$name] = $this->input->post('value');
            $check = $this->Madmin->get_by(['id' => $id, 'delete_status' => 0], 'project_type');
            if ($check != null) {
                $insert = $this->Madmin->update(['id' => $id], $data, 'project_type');
                $response = [
                    'status' => 1,
                    'msg' => 'Thành công'
                ];
            } else {
                $response = [
                    'status' => 0,
                    'msg' => 'Loại dự án không tồn tại. Vui lòng kiểm tra lại'
                ];
            }
        }
        echo json_encode($response);
    }
    // / loại công việc 
    public function job_type()
    {
        if (check_role() == 5 || check_role() == 4 || check_role() == 3 || check_role() == 0) {
            set_status_header(404);
            return $this->load->view('errors/html/error_role');
        } else {
            $page = $this->uri->segment(2);
            if ($page < 1 || $page == '') {
                $page = 1;
            }
            $limit = 10;
            $start = $limit * ($page - 1);
            $where = "AND job_type.id > 0 ";
            if ($this->input->get('n') != '') {
                $n = $this->input->get('n');
                $where .= " AND job_type.name LIKE '$n'";
            }
            if ($this->input->get('au') != '') {
                $au = $this->input->get('au');
                $where .= " AND job_type.author = $au";
            }
            if ($this->input->get('type') != '') {
                $type = $this->input->get('type');
                $where .= " AND job_type.status = $type";
            }
            if ($this->input->get('cs') > 0) {
                $created_start = $this->input->get('cs');
                $where .= " AND job_type.created_at >= $created_start";
            }
            if ($this->input->get('ce') > 0) {
                $created_end = $this->input->get('ce');
                $where .= " AND job_type.created_at <= $created_end";
            }
            $job_types = $this->Madmin->query_sql("SELECT job_type.*,users.name as name_author  FROM job_type JOIN users ON users.id=job_type.author WHERE delete_status = 0 $where");
            pagination('/loai-cong-viec/', count($job_types), $limit);
            $job_types_limit = $this->Madmin->query_sql("SELECT job_type.*,users.name as name_author  FROM job_type JOIN users ON users.id=job_type.author WHERE delete_status = 0 $where LIMIT $start,$limit");
            $data['list'] = $job_types_limit;
            $data['name'] = $this->Madmin->query_sql("SELECT DISTINCT name FROM job_type WHERE delete_status = 0  ORDER BY name ASC");
            $data['author'] = $this->Madmin->query_sql("SELECT id,name,role  FROM users WHERE role = 1 OR role = 2  ORDER BY name ASC");
            $data['canonical'] = base_url('laoi-du-an/');
            $data['meta_title'] = 'Loại công việc';
            $data['content'] = 'setting/job_type';
            $data['list_js'] = [
                'sweetalert.min.js',
                'jquery.validate.min.js',
                'setting/job_type.js',
            ];
            $data['list_css'] = [
                'sweetalert.css',
                'setting/job_type.css',
            ];
            return $this->load->view('index', $data);
        }
    }

    public function add_job_type()
    {
        if (check_role() == 5 || check_role() == 4 || check_role() == 3 || check_role() == 0) {
            $response = [
                'status' => 0,
                'msg' => 'Không có quyền thao tác'
            ];
        } else {
            $id = $this->input->post('id');
            $data['name'] = $name =  $this->input->post('name');
            $data['status'] = $this->input->post('status');
            $data['updated_at'] = time();
            $where = [
                'name' => $name,
                'delete_status' => 0
            ];
            if ($id > 0) {
                $where['id !='] = $id;
            }
            $check = $this->Madmin->get_by($where, 'job_type');
            if ($check == null) {
                if ($id > 0) {
                    $insert = $this->Madmin->update(['id' => $id], $data, 'job_type');
                } else {
                    $data['author'] = $_SESSION['user']['id'];
                    $data['created_at'] = time();
                    $insert = $this->Madmin->insert($data, 'job_type');
                }
                $response = [
                    'status' => 1,
                    'msg' => 'Thành công'
                ];
            } else {
                $response = [
                    'status' => 0,
                    'msg' => 'Tên đầu việc đã tồn tại'
                ];
            }
        }
        echo json_encode($response);
    }
    public function change_job_type()
    {
        if (check_role() == 5 || check_role() == 4 || check_role() == 3 || check_role() == 0) {
            $response = [
                'status' => 0,
                'msg' => 'Không có quyền thao tác'
            ];
        } else {
            $id =  $this->input->post('id');
            $name =  $this->input->post('name');
            $data[$name] = $this->input->post('value');
            $check = $this->Madmin->get_by(['id' => $id, 'delete_status' => 0], 'job_type');
            if ($check != null) {
                $insert = $this->Madmin->update(['id' => $id], $data, 'job_type');
                $response = [
                    'status' => 1,
                    'msg' => 'Thành công'
                ];
            } else {
                $response = [
                    'status' => 0,
                    'msg' => 'Loại công việc không tồn tại. Vui lòng kiểm tra lại'
                ];
            }
        }
        echo json_encode($response);
    }
    // / đầu việc cần index 
    public function job_index()
    {
        if (check_role() == 5 || check_role() == 4 || check_role() == 3 || check_role() == 0) {
            set_status_header(404);
            return $this->load->view('errors/html/error_role');
        } else {
            $page = $this->uri->segment(2);
            if ($page < 1 || $page == '') {
                $page = 1;
            }
            $limit = 10;
            $start = $limit * ($page - 1);
            $where = "AND job_index.id > 0 ";
            if ($this->input->get('n') != '') {
                $n = $this->input->get('n');
                $where .= " AND job_index.name LIKE '$n'";
            }
            if ($this->input->get('au') != '') {
                $au = $this->input->get('au');
                $where .= " AND job_index.author = $au";
            }
            if ($this->input->get('type') != '') {
                $type = $this->input->get('type');
                $where .= " AND job_index.status = $type";
            }
            if ($this->input->get('cs') > 0) {
                $created_start = $this->input->get('cs');
                $where .= " AND job_index.created_at >= $created_start";
            }
            if ($this->input->get('ce') > 0) {
                $created_end = $this->input->get('ce');
                $where .= " AND job_index.created_at <= $created_end";
            }
            $job_indexs = $this->Madmin->query_sql("SELECT job_index.*,users.name as name_author  FROM job_index JOIN users ON users.id=job_index.author WHERE delete_status = 0 $where");
            pagination('/dau-viec-can-index/', count($job_indexs), $limit);
            $job_indexs_limit = $this->Madmin->query_sql("SELECT job_index.*,users.name as name_author  FROM job_index JOIN users ON users.id=job_index.author WHERE delete_status = 0 $where LIMIT $start,$limit");
            $data['list'] = $job_indexs_limit;
            $data['name'] = $this->Madmin->query_sql("SELECT DISTINCT name FROM job_index WHERE delete_status = 0 ORDER BY name ASC");
            $data['author'] = $this->Madmin->query_sql("SELECT id,name,role  FROM users WHERE role = 1 OR role = 2 ORDER BY name ASC");
            $data['canonical'] = base_url('loai-du-an/');
            $data['meta_title'] = 'Đầu việc cần index';
            $data['content'] = 'setting/job_index';
            $data['list_js'] = [
                'sweetalert.min.js',
                'jquery.validate.min.js',
                'setting/job_index.js',
            ];
            $data['list_css'] = [
                'sweetalert.css',
                'setting/job_index.css',
            ];
            return $this->load->view('index', $data);
        }
    }

    public function add_job_index()
    {
        if (check_role() == 5 || check_role() == 4 || check_role() == 3 || check_role() == 0) {
            $response = [
                'status' => 0,
                'msg' => 'Không có quyền thao tác'
            ];
        } else {
            $id = $this->input->post('id');
            $data['name'] = $name =  $this->input->post('name');
            $data['status'] = $this->input->post('status');
            $data['updated_at'] = time();
            $where = [
                'name' => $name,
                'delete_status' => 0
            ];
            if ($id > 0) {
                $where['id !='] = $id;
            }
            $check = $this->Madmin->get_by($where, 'job_index');
            if ($check == null) {
                if ($id > 0) {
                    $insert = $this->Madmin->update(['id' => $id], $data, 'job_index');
                } else {
                    $data['author'] = $_SESSION['user']['id'];
                    $data['created_at'] = time();
                    $insert = $this->Madmin->insert($data, 'job_index');
                }
                $response = [
                    'status' => 1,
                    'msg' => 'Thành công'
                ];
            } else {
                $response = [
                    'status' => 0,
                    'msg' => 'Tên đầu việc đã tồn tại'
                ];
            }
        }
        echo json_encode($response);
    }
    public function change_job_index()
    {
        if (check_role() == 5 || check_role() == 4 || check_role() == 3 || check_role() == 0) {
            $response = [
                'status' => 0,
                'msg' => 'Không có quyền thao tác'
            ];
        } else {
            $id =  $this->input->post('id');
            $name =  $this->input->post('name');
            $data[$name] = $this->input->post('value');
            $check = $this->Madmin->get_by(['id' => $id, 'delete_status' => 0], 'job_index');
            if ($check != null) {
                $insert = $this->Madmin->update(['id' => $id], $data, 'job_index');
                $response = [
                    'status' => 1,
                    'msg' => 'Thành công'
                ];
            } else {
                $response = [
                    'status' => 0,
                    'msg' => 'Tên đầu việc không tồn tại. Vui lòng kiểm tra lại'
                ];
            }
        }
        echo json_encode($response);
    }
    // / thông tin nguồn nhập
    public function input_source()
    {
        if (check_role() == 5 || check_role() == 4 || check_role() == 3 || check_role() == 0) {
            set_status_header(404);
            return $this->load->view('errors/html/error_role');
        } else {
            $page = $this->uri->segment(2);
            if ($page < 1 || $page == '') {
                $page = 1;
            }
            $limit = 10;
            $start = $limit * ($page - 1);
            $where = "AND input_source.id > 0 ";
            if ($this->input->get('ni') != '') {
                $ni = $this->input->get('ni');
                $where .= " AND input_source.name LIKE '$ni'";
            }
            if ($this->input->get('au') != '') {
                $au = $this->input->get('au');
                $where .= " AND input_source.author = $au";
            }
            if ($this->input->get('nb') != '') {
                $nb = $this->input->get('nb');
                $where .= " AND input_source.bank = $nb";
            }
            if ($this->input->get('stk') != '') {
                $stk = $this->input->get('stk');
                $where .= " AND input_source.stk = $stk";
            }
            if ($this->input->get('type') != '') {
                $type = $this->input->get('type');
                $where .= " AND input_source.status = $type";
            }
            if ($this->input->get('cs') > 0) {
                $created_start = $this->input->get('cs');
                $where .= " AND input_source.created_at >= $created_start";
            }
            if ($this->input->get('ce') > 0) {
                $created_end = $this->input->get('ce');
                $where .= " AND input_source.created_at <= $created_end";
            }
            $input_sources = $this->Madmin->query_sql("SELECT input_source.*,users.name as name_author, bank.name as name_bank  FROM input_source JOIN users ON users.id=input_source.author JOIN bank ON bank.id=input_source.bank AND input_source.delete_status = 0 $where");
            pagination('/thong-tin-nguon-nhan/', count($input_sources), $limit);
            $input_sources_limit = $this->Madmin->query_sql("SELECT input_source.*,users.name as name_author, bank.name as name_bank  FROM input_source JOIN users ON users.id=input_source.author JOIN bank ON bank.id=input_source.bank AND input_source.delete_status = 0 $where LIMIT $start,$limit");
            $data['list'] = $input_sources_limit;
            $data['bank'] = $this->Madmin->query_sql("SELECT id,name FROM bank ORDER BY CASE WHEN id = 50 THEN 0 ELSE 1 END, id ASC, name ASC ");
            $data['name_input'] = $this->Madmin->query_sql("SELECT DISTINCT name FROM input_source WHERE delete_status = 0 ORDER BY name ASC");
            $data['stk'] = $this->Madmin->query_sql("SELECT DISTINCT stk FROM input_source WHERE delete_status = 0");
            $data['author'] = $this->Madmin->query_sql("SELECT id,name,role  FROM users WHERE role = 1 OR role = 2 ORDER BY name ASC");
            $data['canonical'] = base_url('laoi-du-an/');
            $data['meta_title'] = 'Thông tin nguồn nhập';
            $data['content'] = 'setting/input_source';
            $data['list_js'] = [
                'sweetalert.min.js',
                'jquery.validate.min.js',
                'setting/input_source.js',
            ];
            $data['list_css'] = [
                'sweetalert.css',
                'setting/input_source.css',
            ];
            return $this->load->view('index', $data);
        }
    }

    public function add_input_source()
    {
        if (check_role() == 5 || check_role() == 4 || check_role() == 3 || check_role() == 0) {
            $response = [
                'status' => 0,
                'msg' => 'Không có quyền thao tác'
            ];
        } else {
            $id = $this->input->post('id');
            $data['name'] =  $this->input->post('name');
            $data['stk'] = $stk  = $this->input->post('stk');
            $data['bank'] = $this->input->post('bank');
            $data['status'] = $this->input->post('status');
            $data['updated_at'] = time();
            $where = [
                'stk' => $stk,
                'delete_status' => 0
            ];
            if ($id > 0) {
                $where['id !='] = $id;
            }
            $check = $this->Madmin->get_by($where, 'input_source');
            if ($check == null) {
                if ($id > 0) {
                    $insert = $this->Madmin->update(['id' => $id], $data, 'input_source');
                } else {
                    $data['author'] = $_SESSION['user']['id'];
                    $data['created_at'] = time();
                    $insert = $this->Madmin->insert($data, 'input_source');
                }
                $response = [
                    'status' => 1,
                    'msg' => 'Thành công'
                ];
            } else {
                $response = [
                    'status' => 0,
                    'msg' => 'Số tài khoản đã tồn tại'
                ];
            }
        }
        echo json_encode($response);
    }
    public function change_input_source()
    {
        if (check_role() == 5 || check_role() == 4 || check_role() == 3 || check_role() == 0) {
            $response = [
                'status' => 0,
                'msg' => 'Không có quyền thao tác'
            ];
        } else {
            $id =  $this->input->post('id');
            $name =  $this->input->post('name');
            $data[$name] = $this->input->post('value');
            $check = $this->Madmin->get_by(['id' => $id, 'delete_status' => 0], 'input_source');
            if ($check != null) {
                $insert = $this->Madmin->update(['id' => $id], $data, 'input_source');
                $response = [
                    'status' => 1,
                    'msg' => 'Thành công'
                ];
            } else {
                $response = [
                    'status' => 0,
                    'msg' => 'Tên đầu việc không tồn tại. Vui lòng kiểm tra lại'
                ];
            }
        }
        echo json_encode($response);
    }
    public function delete_type()
    {
        if (check_role() == 5 || check_role() == 4 || check_role() == 3  || check_role() == 0) {
            $response = [
                'status' => 0,
                'msg' => 'Không có quyền thao tác'
            ];
        } else {
            $arr_id = explode(',', $this->input->post('arr_id'));
            $table = $this->input->post('table');
            if ($arr_id != null) {
                foreach ($arr_id as $id) {
                    $type = $this->Madmin->query_sql_row("SELECT id  FROM $table WHERE id = $id");
                    if ($type != null) {
                        $update = $this->Madmin->update(['id' => $id], ['delete_status' => 1], $table);
                        $response = [
                            'status' => 1,
                            'msg' => 'Thành công'
                        ];
                    } else {
                        $response = [
                            'status' => 0,
                            'msg' => 'Không tìm thấy dữ liệu'
                        ];
                    }
                }
            } else {
                $response = [
                    'status' => 0,
                    'msg' => 'Chưa chọn'
                ];
            }
        }
        echo json_encode($response);
    }

    public function get_table()
    {
        $id = $this->input->post('id');
        $table = $this->input->post('table');
        if ($id > 0 && $table != '') {
            $data = $this->Madmin->get_by(['id' => $id], $table);
            if ($data != null) {
                $response = [
                    'status' => 1,
                    'array_data' => $data,
                    'msg' => 'Thành công'
                ];
            } else {
                $response = [
                    'status' => 0,
                    'msg' => 'Không tìm thấy dữ liệu'
                ];
            }
        } else {
            $response = [
                'status' => 0,
                'msg' => 'Chưa lựa chọn'
            ];
        }
        echo json_encode($response);
    }
}
