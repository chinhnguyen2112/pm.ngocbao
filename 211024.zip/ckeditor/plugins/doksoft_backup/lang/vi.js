 CKEDITOR.plugins.setLang("doksoft_backup", "vi", {
 	label: 'Khôi phục',
 	save: 'Thực hiện sao lưu bây giờ',
 	load: 'Khôi phục sao lưu',
 	no_backups: 'Không có sao lưu',
 	no_backups_desc: 'Cửa sổ này sẽ hiển thị danh sách các bức ảnh chụp khi bạn thực hiện ít nhất một sao lưu',
 	html_length: 'Độ dài mã',
 	word_count: 'Số từ',
 	symbol_count: 'Số ký tự',
 	remove_all: 'Hủy bỏ tất cả bản sao lưu',
 	confirm_remove_all: 'Bạn có chắc là bạn muốn loại bỏ tất cả các bản sao lưu cho tài liệu này?',
 	msg_select: 'Chọn bản sao lưu để khôi phục lại nó',
 	mess: 'Bạn có chắc là bạn muốn thay thế văn bản hiện hành bằng văn bản của bản sao lưu?',
 	mess1: 'Bạn có chắc là bạn muốn loại bỏ toàn bộ bản sao lưu?'
 });