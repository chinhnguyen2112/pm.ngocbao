 CKEDITOR.plugins.setLang("doksoft_backup", "en", {
 	label: 'Restore',
 	save: 'Perform backup now',
 	load: 'Restore backup',
 	no_backups: 'There are no backups yet',
 	no_backups_desc: 'This windows will show list of snapshots when you make at least one backup',
 	html_length: 'HTML length',
 	word_count: 'Word count',
 	symbol_count: 'Symbol count',
 	remove_all: 'Remove all snapshots',
 	confirm_remove_all: 'Are you sure you want to remove all snapshots for this document?',
 	msg_select: 'Select snapshot to restore it',
 	mess: 'Are you sure you want to replace the existing text, the text of the backup?',
 	mess1: 'Are you sure you want to remove the entire backup?'
 });