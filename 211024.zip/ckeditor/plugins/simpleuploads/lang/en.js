﻿CKEDITOR.plugins.setLang( 'simpleuploads', 'en',
	{
		"addFile": "Add a file",
      "addImage": "Add an image",
      "processing": "Processing...",
      "fileTooBig": "The file is too big, please use a smaller one.",
      "invalidExtension": "Invalid file type, please use only valid files.",
      "nonAcceptedExtension": "The file type is not valid, please use only valid files:\r\n%0",
      "nonImageExtension": "You must select an image",
      "imageTooWide": "The image is too wide",
      "imageTooTall": "The image is too tall"
	}
);