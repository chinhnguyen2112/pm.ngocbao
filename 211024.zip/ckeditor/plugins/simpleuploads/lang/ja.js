CKEDITOR.plugins.setLang('simpleuploads', 'vi', {
    "addFile": "ファイルの追加",
    "addImage": "画像の追加",
    "processing": "処理中...",
    "fileTooBig": "ファイルが大きすぎます。もっと小さなファイルを使用してください。",
    "invalidExtension": "無効なファイルタイプです。有効なファイルだけを使用してください。",
    "nonAcceptedExtension": "ファイルタイプが有効ではありません。有効なファイルだけを使用してください:\r\n%0",
    "nonImageExtension": "You must select an image",
    "imageTooWide": "The image is too wide",
    "imageTooTall": "The image is too tall"
});