CKEDITOR.plugins.setLang( 'simpleuploads', 'vi',
	{
		"addFile": "Thêm một tập tin",
      "addImage": "Thêm một hình ảnh",
      "processing": "Đang xử lý ...",
      "fileTooBig": "Các tập tin quá lớn, hãy sử dụng tập tin nhỏ hơn.",
      "invalidExtension": "Loại tập tin không hợp lệ, hãy sử dụng các tập tin hợp lệ.",
      "nonAcceptedExtension": "Tập tin bạn chọn không trong danh sách các tập tin cho phép:\r\n%0",
      "nonImageExtension": "Bạn phải chọn một hình ảnh",
      "imageTooWide": "Hình ảnh quá rộng",
      "imageTooTall": "Hình ảnh quá cao"
	}
);