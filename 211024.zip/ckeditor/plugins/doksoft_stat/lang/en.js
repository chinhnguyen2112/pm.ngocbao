 CKEDITOR.plugins.setLang("doksoft_stat","en",{
  strlen:'chars',
	sel:'selected',
	source:'source',
	words:'words',
 });
