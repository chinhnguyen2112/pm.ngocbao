 CKEDITOR.plugins.setLang("doksoft_stat","vi",{
  strlen:'Ký tự',
	sel:'lựa chọn',
	source:'nguồn',
	words:'từ',
 });
