CKEDITOR.plugins.setLang(
	
	'doksoft_html',
	
	'en',
	{	
			doksoft_html:
		{
			button_label: "Insert HTML",
		}
	}
);
