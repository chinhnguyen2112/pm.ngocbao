<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Manager extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Madmin');
        $this->load->database();
        $this->load->helper(['url', 'func_helper', 'images']);
        $this->load->library(['session', 'pagination311', 'upload']);
        if (admin()) {
            $g_admin = $this->Madmin->get_by(['id' => $_SESSION['user']['id']], 'users');
            $this->session->set_userdata('users', $g_admin);
        }
    }
    public function index()
    {
        if (admin()) {
        $data = [];
        $data['content'] = 'main';
        return $this->load->view('index', $data);
        } else {
            redirect('/dang-nhap/');
        }
    }
    public function logout()
    {
        unset($_SESSION['admin']);
        header('Location: /');
    }
    public function login()
    {
        if (!admin()) {
            return $this->load->view('login');
        } else {
            redirect('/');
        }
    }
    public function ajax_login()
    {
        $user = $this->input->post('username');
        $pass = md5($this->input->post('password'));
        $check_admin = $this->Madmin->get_by(['username' => $user, 'password' => $pass], 'users');
        if ($check_admin != null) {
            $this->session->set_userdata('user', $check_admin);
            $response = [
                'status' => 1,
                'msg' => 'Đăng nhập thành công'
            ];
        } else {
            $response = [
                'status' => 0,
                'msg' => 'Sai thông tin đăng nhập, tên người dùng hoặc mật khẩu không hợp lệ'
            ];
        }
        echo json_encode($response);
    }
    public function manager_project()
    {
        if (admin()) {
            if (check_role() == 5 || check_role() == 4 || check_role() == 3  || check_role() == 0) {
                set_status_header(404);
                return $this->load->view('errors/html/error_role');
            } else {
                $project = $this->Madmin->query_sql("SELECT 
            projects.*, 
            users.name AS name_author, 
            project_type.name AS name_project_type, 
            SUM(jobs.price) AS job_price,
            (SELECT COUNT(*) FROM ctv_jobs WHERE ctv_jobs.project_id = projects.id) AS ctv_job_count,
            (SELECT COUNT(*) FROM jobs WHERE jobs.project_id = projects.id) AS job_count,
            (SELECT COUNT(*) FROM jobs WHERE jobs.project_id = projects.id AND jobs.status = 1) AS job_completion_count,
            (SELECT completion_time 
            FROM ctv_jobs 
            WHERE ctv_jobs.project_id = projects.id AND ctv_jobs.status = 1 
            ORDER BY ctv_jobs.completion_time LIMIT 1) AS ctv_job_completion_time
            FROM 
                projects 
            JOIN 
                users ON users.id = projects.author 
            JOIN 
                project_type ON project_type.id = projects.project_type
            LEFT JOIN 
                jobs ON jobs.project_id = projects.id
            GROUP BY 
            projects.id, users.name, project_type.name;");
                $data['project'] = $project;
                $data['canonical'] = base_url('quan-ly-du-an/');
                $data['meta_title'] = 'Quản lý dự án';
                $data['content'] = 'manager/project';
                $data['list_js'] = [
                    'manager/project.js',
                ];
                $data['list_css'] = [
                    'manager/project.css'
                ];
                return $this->load->view('index', $data);
            }
        } else {
            redirect('/dang-nhap/');
        }
    }
    public function project()
    {
        if (admin()) {
            if (check_role() == 5 || check_role() == 4 || check_role() == 3  || check_role() == 0) {
                set_status_header(404);
                return $this->load->view('errors/html/error_role');
            } else {
                $data['project_type'] = $this->Madmin->query_sql("SELECT id,name  FROM project_type WHERE status = 1");
                $data['canonical'] = base_url('quan-ly-du-an/');
                $data['meta_title'] = 'Quản lý dự án';
                $data['content'] = 'manager/add_project';
                $data['list_js'] = [
                    'sweetalert.min.js',
                    'jquery.validate.min.js',
                    'manager/add_project.js',
                ];
                $data['list_css'] = [
                    'sweetalert.css',
                    'manager/add_project.css'
                ];
                return $this->load->view('index', $data);
            }
        } else {
            redirect('/dang-nhap/');
        }
    }
    public function add_project()
    {
        if (check_role() == 5 || check_role() == 4 || check_role() == 3  || check_role() == 0) {
            $response = [
                'status' => 0,
                'msg' => 'Không có quyền thao tác'
            ];
        } else {
            $data['project_type'] = $this->input->post('project_type');
            $data['deadline'] = strtotime($this->input->post('deadline'));
            $data['revenue'] = $this->input->post('revenue');
            $data['info'] = $this->input->post('info');
            $data['website'] = $this->input->post('website');
            $data['file'] = $this->input->post('file');
            $data['note_index'] = $this->input->post('note_index');
            $data['note'] = $this->input->post('note');
            $data['status_index'] = $status_index = $this->input->post('status_index');
            $data_index =  $this->input->post('data_index');
            $data['author'] = $_SESSION['user']['id'];
            $data['time_index'] = time();
            $data['updated_at'] = time();
            $data['created_at'] = time();
            $customer = $this->input->post('customer');
            $data['customer'] = $this->input->post('customer');
            $data['check_index'] = 0;
            if ($status_index == 1) {
                $data['data_index'] = json_encode($data_index);
                $data['check_index'] = 4;
            }
            $insert = $this->Madmin->insert($data, 'projects');
            $response = [
                'status' => 1,
                'msg' => 'Thành công'
            ];
        }
        echo json_encode($response);
    }
    public function manager_job()
    {
        if (admin()) {
            if (check_role() == 5 || check_role() == 4 || check_role() == 3  || check_role() == 0) {
                set_status_header(404);
                return $this->load->view('errors/html/error_role');
            } else {
                $jobs = $this->Madmin->query_sql("SELECT jobs.*,job_type.name as name_job_type,users.name as name_author,projects.website as website FROM jobs JOIN projects ON projects.id=jobs.project_id JOIN job_type ON job_type.id=jobs.job_type JOIN users ON users.id=jobs.author");
                foreach ($jobs as $key => &$val) {
                    $ctv_job = $this->Madmin->query_sql_row("SELECT ctv,deadline,time_qa_check,status_qa_check,content_qa_check,check_replly,qa_id,status,completion_time,created_at  FROM ctv_jobs WHERE job_id = {$val['id']}");
                    if ($ctv_job != null) {
                        $name_ctv = $this->name_user($ctv_job['ctv']);
                        $val['name_ctv'] = $name_ctv;
                        $val['qa_name'] = ($ctv_job['qa_id'] > 0) ? get_name($ctv_job['qa_id']) : '--QA thực hiện--';
                        $val['status_qa_check'] = $ctv_job['status_qa_check'];
                        $val['time_qa_check'] = $ctv_job['time_qa_check'];
                        $val['content_qa_check'] = ($ctv_job['content_qa_check'] != '') ? $ctv_job['content_qa_check'] : 'Đánh giá...';
                        $val['deadline_ctv'] = $ctv_job['deadline'];
                        $val['ctv_check_replly'] = $ctv_job['check_replly'];
                        $val['status_ctv'] = $ctv_job['status'];
                        $val['time_ctv_job'] = $ctv_job['created_at'];
                        $val['completion_ctv_job'] = $ctv_job['completion_time'];
                    } else {
                        $val['name_ctv'] = 'Chưa giao việc';
                        $val['qa_name'] = "--QA thực hiện--";
                        $val['status_qa_check'] = 0;
                        $val['time_qa_check'] = 0;
                        $val['content_qa_check'] = "--Đánh giá--";
                        $val['deadline_ctv'] = 0;
                        $val['ctv_check_replly'] = 0;
                        $val['status_ctv'] = -1;
                        $val['time_ctv_job'] = 0;
                        $val['completion_ctv_job'] = 0;
                    }
                }
                $data['jobs'] = $jobs;
                $data['canonical'] = base_url('quan-ly-du-an/');
                $data['meta_title'] = 'Quản lý dự án';
                $data['content'] = 'manager/job';
                $data['list_js'] = [
                    'manager/job.js',
                ];
                $data['list_css'] = [
                    'manager/job.css'
                ];
                return $this->load->view('index', $data);
            }
        } else {
            redirect('/dang-nhap/');
        }
    }
    public function job()
    {
        if (admin()) {
            if (check_role() == 5 || check_role() == 4 || check_role() == 3  || check_role() == 0) {
                set_status_header(404);
                return $this->load->view('errors/html/error_role');
            } else {
                $data['job_type'] = $this->Madmin->query_sql("SELECT id,name  FROM job_type WHERE status = 1");
                $data['projects'] = $this->Madmin->query_sql("SELECT id  FROM projects ");
                $data['ctv'] = $this->Madmin->query_sql("SELECT id,name  FROM users where role=5 AND status = 1 ");
                $data['canonical'] = base_url('quan-ly-du-an/');
                $data['meta_title'] = 'Quản lý dự án';
                $data['content'] = 'manager/add_job';
                $data['list_js'] = [
                    'sweetalert.min.js',
                    'jquery.validate.min.js',
                    'manager/add_job.js',
                ];
                $data['list_css'] = [
                    'sweetalert.css',
                    'manager/add_job.css'
                ];
                return $this->load->view('index', $data);
            }
        } else {
            redirect('/dang-nhap/');
        }
    }
    public function add_job()
    {
        if (check_role() == 5 || check_role() == 4 || check_role() == 3  || check_role() == 0) {
            $response = [
                'status' => 0,
                'msg' => 'Không có quyền thao tác'
            ];
        } else {
            $data['project_id'] = $project_id = $this->input->post('project_id');
            $data['code'] = $this->count_job($project_id);
            $data['job_type'] = $this->input->post('job_type');
            $data['price'] = $this->input->post('price');
            $data['z_index'] = $this->input->post('z_index');
            $data['info'] = $this->input->post('info');
            $data['note_ctv'] = $this->input->post('note_ctv');
            $data['note_qa'] = $this->input->post('note_qa');
            $data['note'] = $this->input->post('note');
            $data['status_index'] = $this->input->post('status_index');
            $data['status_qa'] = $this->input->post('status_qa');
            $data['author'] = $_SESSION['user']['id'];
            $data['updated_at'] = time();
            $data['created_at'] = time();
            $ctv = $this->input->post('ctv');
            $deadline = $this->input->post('deadline');
            $insert = $this->Madmin->insert($data, 'jobs');
            
            $check = $this->Madmin->get_by(['id' => $project_id], 'projects');
            $data_project['status'] = 2; 
            if($check['time_start'] == ''){
                $data_project['time_start'] = time(); 
            }
            $update_project = $this->Madmin->update(['id' => $project_id], $data_project, 'projects'); // bắt đầu triển khai
            if ($ctv > 0) {
                $data_2['project_id'] = $project_id;
                $data_2['job_id'] = $insert;
                $data_2['ctv'] = $ctv;
                $data_2['deadline'] = strtotime($deadline);
                $data_2['created_at'] = time();
                $data_2['updated_at'] = time();
                $insert_2 = $this->Madmin->insert($data_2, 'ctv_jobs');
            }
            $response = [
                'status' => 1,
                'msg' => 'Thành công'
            ];
        }
        echo json_encode($response);
    }
    function count_job($project)
    {
        $num = $this->Madmin->num_rows(['project_id' => $project], 'jobs');
        $id_project = project_id($project);
        $code = $id_project . '_CV' . ++$num;
        return $code;
    }
    function name_user($id)
    {
        $data = $this->Madmin->query_sql_row("SELECT name  FROM users where id = $id");
        return $data['name'];
    }
    public function manager_collect_money()
    {
        if (admin()) {
            if (check_role() == 5 || check_role() == 4 || check_role() == 3  || check_role() == 0) {
                set_status_header(404);
                return $this->load->view('errors/html/error_role');
            } else {
                $collect_moneys = $this->Madmin->query_sql("SELECT collect_money.*,input_source.name as name_input_source,stk,input_source.bank as id_bank FROM collect_money JOIN projects ON projects.id=collect_money.project_id JOIN input_source ON input_source.id=collect_money.input_source ");
                $data['collect_moneys'] = $collect_moneys;
                $data['canonical'] = base_url('quan-ly-du-an/');
                $data['meta_title'] = 'Quản lý dự án';
                $data['content'] = 'manager/collect_money';
                $data['list_js'] = [
                    'manager/collect_money.js',
                ];
                $data['list_css'] = [
                    'manager/collect_money.css'
                ];
                return $this->load->view('index', $data);
            }
        } else {
            redirect('/dang-nhap/');
        }
    }
    public function collect_money()
    {
        if (admin()) {
            if (check_role() == 5 || check_role() == 4 || check_role() == 3  || check_role() == 0) {
                set_status_header(404);
                return $this->load->view('errors/html/error_role');
            } else {
                $data['projects'] = $this->Madmin->query_sql("SELECT id  FROM projects ");
                $data['input_source'] = $this->Madmin->query_sql("SELECT input_source.id,acronym,input_source.name,stk  FROM input_source join bank ON bank.id=input_source.bank WHERE input_source.status = 1 ");
                $data['ctv'] = $this->Madmin->query_sql("SELECT id,name  FROM users where role=5 AND status = 1 ");
                $data['canonical'] = base_url('quan-ly-du-an/');
                $data['meta_title'] = 'Quản lý dự án';
                $data['content'] = 'manager/add_collect_money';
                $data['list_js'] = [
                    'sweetalert.min.js',
                    'jquery.validate.min.js',
                    'manager/add_collect_money.js',
                ];
                $data['list_css'] = [
                    'sweetalert.css',
                    'manager/add_collect_money.css'
                ];
                return $this->load->view('index', $data);
            }
        } else {
            redirect('/dang-nhap/');
        }
    }
    public function add_collect_money()
    {
        if (check_role() == 5 || check_role() == 4 || check_role() == 3  || check_role() == 0) {
            $response = [
                'status' => 0,
                'msg' => 'Không có quyền thao tác'
            ];
        } else {
            $data['money'] = $this->input->post('money');
            $data['customer'] = $this->input->post('customer');
            $data['bank_type'] = $this->input->post('bank_type');
            $data['bank_status'] = $this->input->post('bank_status');
            $data['note'] = $this->input->post('note');
            $data['bank_content'] = $this->input->post('bank_content');
            $data['input_source'] = $this->input->post('input_source');
            $data['bank_time'] = strtotime($this->input->post('bank_time'));
            $data['project_id'] = $this->input->post('project_id');
            $data['bank_code'] = $bank_code =  $this->input->post('bank_code');
            $data['updated_at'] = time();
            $data['created_at'] = time();
            if (!is_dir('upload/bank_image/')) {
                mkdir('upload/bank_image/', 0755, TRUE);
            }
            if (isset($_FILES['bank_image']) && $_FILES['bank_image']['name'] !== "") {
                $filedata         = $_FILES['bank_image']['tmp_name'];
                $thumb_path        = 'upload/bank_image/' . $bank_code . '.jpg';
                $imguser = $bank_code . '.jpg';
                $config['file_name'] = $imguser;
                $config['upload_path'] = 'upload/bank_image';
                $config['allowed_types'] = 'jpg|png';
                $this->load->library('upload', $config);
                $this->upload->initialize($config);
                if (!$this->upload->do_upload('bank_image')) {
                    echo $this->upload->display_errors();
                } else {
                    $this->upload->data();
                    $data['bank_image'] = $thumb_path;
                }
            }
            $insert = $this->Madmin->insert($data, 'collect_money');
            $response = [
                'status' => 1,
                'msg' => 'Thành công'
            ];
        }
        echo json_encode($response);
    }
}
