<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Setting extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Madmin');
        $this->load->database();
        $this->load->helper(['url', 'func_helper', 'images']);
        $this->load->library(['session', 'pagination311', 'upload']);
        if (admin()) {
            $g_admin = $this->Madmin->get_by(['id' => $_SESSION['user']['id']], 'users');
            $this->session->set_userdata('users', $g_admin);
        } else {
            redirect('/dang-nhap/');
        }
    }
    public function project_type()
    {
        if (check_role() == 5 || check_role() == 4 || check_role() == 3 || check_role() == 0) {
            set_status_header(404);
            return $this->load->view('errors/html/error_role');
        } else {
            $data['list'] = $this->Madmin->query_sql("SELECT project_type.*,users.name as name_author  FROM project_type JOIN users ON users.id=project_type.author");
            $data['canonical'] = base_url('laoi-du-an/');
            $data['meta_title'] = 'Loại dự án';
            $data['content'] = 'setting/project_type';
            $data['list_js'] = [
                'sweetalert.min.js',
                'jquery.validate.min.js',
                'setting/project_type.js',
            ];
            $data['list_css'] = [
                'sweetalert.css',
                'setting/project_type.css',
            ];
            return $this->load->view('index', $data);
        }
    }
    public function add_project_type()
    {
        if (check_role() == 5 || check_role() == 4 || check_role() == 3 || check_role() == 0) {
            $response = [
                'status' => 0,
                'msg' => 'Không có quyền thao tác'
            ];
        } else {
            $data['name'] = $name =  $this->input->post('name');
            $data['status'] = $this->input->post('status');
            $data['updated_at'] = time();
            $data['created_at'] = time();
            $data['author'] = $_SESSION['user']['id'];
            $check = $this->Madmin->get_by(['name' => $name], 'project_type');
            if ($check == null) {
                $insert = $this->Madmin->insert($data, 'project_type');
                $response = [
                    'status' => 1,
                    'msg' => 'Thành công'
                ];
            } else {
                $response = [
                    'status' => 0,
                    'msg' => 'Tên loại dự án đã tồn tại'
                ];
            }
        }
        echo json_encode($response);
    }
    public function change_project_type()
    {
        if (check_role() == 5 || check_role() == 4 || check_role() == 3 || check_role() == 0) {
            $response = [
                'status' => 0,
                'msg' => 'Không có quyền thao tác'
            ];
        } else {
            $id =  $this->input->post('id');
            $name =  $this->input->post('name');
            $data[$name] = $this->input->post('value');
            $check = $this->Madmin->get_by(['id' => $id], 'project_type');
            if ($check != null) {
                $insert = $this->Madmin->update(['id' => $id], $data, 'project_type');
                $response = [
                    'status' => 1,
                    'msg' => 'Thành công'
                ];
            } else {
                $response = [
                    'status' => 0,
                    'msg' => 'Loại dự án không tồn tại. Vui lòng kiểm tra lại'
                ];
            }
        }
        echo json_encode($response);
    }
    // / loại công việc 
    public function job_type()
    {
        if (check_role() == 5 || check_role() == 4 || check_role() == 3 || check_role() == 0) {
            set_status_header(404);
            return $this->load->view('errors/html/error_role');
        } else {
            $data['list'] = $this->Madmin->query_sql("SELECT job_type.*,users.name as name_author  FROM job_type JOIN users ON users.id=job_type.author");
            $data['canonical'] = base_url('laoi-du-an/');
            $data['meta_title'] = 'Loại dự án';
            $data['content'] = 'setting/job_type';
            $data['list_js'] = [
                'sweetalert.min.js',
                'jquery.validate.min.js',
                'setting/job_type.js',
            ];
            $data['list_css'] = [
                'sweetalert.css',
                'setting/job_type.css',
            ];
            return $this->load->view('index', $data);
        }
    }

    public function add_job_type()
    {
        if (check_role() == 5 || check_role() == 4 || check_role() == 3 || check_role() == 0) {
            $response = [
                'status' => 0,
                'msg' => 'Không có quyền thao tác'
            ];
        } else {
            $data['name'] = $name =  $this->input->post('name');
            $data['status'] = $this->input->post('status');
            $data['updated_at'] = time();
            $data['created_at'] = time();
            $data['author'] = $_SESSION['user']['id'];
            $check = $this->Madmin->get_by(['name' => $name], 'job_type');
            if ($check == null) {
                $insert = $this->Madmin->insert($data, 'job_type');
                $response = [
                    'status' => 1,
                    'msg' => 'Thành công'
                ];
            } else {
                $response = [
                    'status' => 0,
                    'msg' => 'Tên đầu việc đã tồn tại'
                ];
            }
        }
        echo json_encode($response);
    }
    public function change_job_type()
    {
        if (check_role() == 5 || check_role() == 4 || check_role() == 3 || check_role() == 0) {
            $response = [
                'status' => 0,
                'msg' => 'Không có quyền thao tác'
            ];
        } else {
            $id =  $this->input->post('id');
            $name =  $this->input->post('name');
            $data[$name] = $this->input->post('value');
            $check = $this->Madmin->get_by(['id' => $id], 'job_type');
            if ($check != null) {
                $insert = $this->Madmin->update(['id' => $id], $data, 'job_type');
                $response = [
                    'status' => 1,
                    'msg' => 'Thành công'
                ];
            } else {
                $response = [
                    'status' => 0,
                    'msg' => 'Loại công việc không tồn tại. Vui lòng kiểm tra lại'
                ];
            }
        }
        echo json_encode($response);
    }
    // / đầu việc cần index 
    public function job_index()
    {
        if (check_role() == 5 || check_role() == 4 || check_role() == 3 || check_role() == 0) {
            set_status_header(404);
            return $this->load->view('errors/html/error_role');
        } else {
            $data['list'] = $this->Madmin->query_sql("SELECT job_index.*,users.name as name_author  FROM job_index JOIN users ON users.id=job_index.author");
            $data['canonical'] = base_url('laoi-du-an/');
            $data['meta_title'] = 'Loại dự án';
            $data['content'] = 'setting/job_index';
            $data['list_js'] = [
                'sweetalert.min.js',
                'jquery.validate.min.js',
                'setting/job_index.js',
            ];
            $data['list_css'] = [
                'sweetalert.css',
                'setting/job_index.css',
            ];
            return $this->load->view('index', $data);
        }
    }

    public function add_job_index()
    {
        if (check_role() == 5 || check_role() == 4 || check_role() == 3 || check_role() == 0) {
            $response = [
                'status' => 0,
                'msg' => 'Không có quyền thao tác'
            ];
        } else {
            $data['name'] = $name =  $this->input->post('name');
            $data['status'] = $this->input->post('status');
            $data['updated_at'] = time();
            $data['created_at'] = time();
            $data['author'] = $_SESSION['user']['id'];
            $check = $this->Madmin->get_by(['name' => $name], 'job_index');
            if ($check == null) {
                $insert = $this->Madmin->insert($data, 'job_index');
                $response = [
                    'status' => 1,
                    'msg' => 'Thành công'
                ];
            } else {
                $response = [
                    'status' => 0,
                    'msg' => 'Tên đầu việc đã tồn tại'
                ];
            }
        }
        echo json_encode($response);
    }
    public function change_job_index()
    {
        if (check_role() == 5 || check_role() == 4 || check_role() == 3 || check_role() == 0) {
            $response = [
                'status' => 0,
                'msg' => 'Không có quyền thao tác'
            ];
        } else {
            $id =  $this->input->post('id');
            $name =  $this->input->post('name');
            $data[$name] = $this->input->post('value');
            $check = $this->Madmin->get_by(['id' => $id], 'job_index');
            if ($check != null) {
                $insert = $this->Madmin->update(['id' => $id], $data, 'job_index');
                $response = [
                    'status' => 1,
                    'msg' => 'Thành công'
                ];
            } else {
                $response = [
                    'status' => 0,
                    'msg' => 'Tên đầu việc không tồn tại. Vui lòng kiểm tra lại'
                ];
            }
        }
        echo json_encode($response);
    }
    // / thông tin nguồn nhập
    public function input_source()
    {
        if (check_role() == 5 || check_role() == 4 || check_role() == 3 || check_role() == 0) {
            set_status_header(404);
            return $this->load->view('errors/html/error_role');
        } else {
            $data['list'] = $this->Madmin->query_sql("SELECT input_source.*,users.name as name_author, bank.name as name_bank  FROM input_source JOIN users ON users.id=input_source.author JOIN bank ON bank.id=input_source.bank");
            $data['bank'] = $this->Madmin->query_sql("SELECT id,name FROM bank");
            $data['canonical'] = base_url('laoi-du-an/');
            $data['meta_title'] = 'Loại dự án';
            $data['content'] = 'setting/input_source';
            $data['list_js'] = [
                'sweetalert.min.js',
                'jquery.validate.min.js',
                'select2.min.js',
                'setting/input_source.js',
            ];
            $data['list_css'] = [
                'sweetalert.css',
                'select2.min.css',
                'setting/input_source.css',
            ];
            return $this->load->view('index', $data);
        }
    }

    public function add_input_source()
    {
        if (check_role() == 5 || check_role() == 4 || check_role() == 3 || check_role() == 0) {
            $response = [
                'status' => 0,
                'msg' => 'Không có quyền thao tác'
            ];
        } else {
            $data['name'] =  $this->input->post('name');
            $data['stk'] = $stk  = $this->input->post('stk');
            $data['bank'] = $this->input->post('bank');
            $data['status'] = $this->input->post('status');
            $data['updated_at'] = time();
            $data['created_at'] = time();
            $data['author'] = $_SESSION['user']['id'];
            $check = $this->Madmin->get_by(['stk' => $stk], 'input_source');
            if ($check == null) {
                $insert = $this->Madmin->insert($data, 'input_source');
                $response = [
                    'status' => 1,
                    'msg' => 'Thành công'
                ];
            } else {
                $response = [
                    'status' => 0,
                    'msg' => 'Số tài khoản đã tồn tại'
                ];
            }
        }
        echo json_encode($response);
    }
    public function change_input_source()
    {
        if (check_role() == 5 || check_role() == 4 || check_role() == 3 || check_role() == 0) {
            $response = [
                'status' => 0,
                'msg' => 'Không có quyền thao tác'
            ];
        } else {
            $id =  $this->input->post('id');
            $name =  $this->input->post('name');
            $data[$name] = $this->input->post('value');
            $check = $this->Madmin->get_by(['id' => $id], 'input_source');
            if ($check != null) {
                $insert = $this->Madmin->update(['id' => $id], $data, 'input_source');
                $response = [
                    'status' => 1,
                    'msg' => 'Thành công'
                ];
            } else {
                $response = [
                    'status' => 0,
                    'msg' => 'Tên đầu việc không tồn tại. Vui lòng kiểm tra lại'
                ];
            }
        }
        echo json_encode($response);
    }
}
