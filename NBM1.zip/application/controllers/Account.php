<?php
error_reporting(1);
defined('BASEPATH') or exit('No direct script access allowed');
class Account extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Madmin');
        $this->load->database();
        $this->load->helper(['url', 'func_helper', 'images']);
        $this->load->library(['session', 'pagination311', 'upload']);
        if (admin()) {
            $g_admin = $this->Madmin->get_by(['id' => $_SESSION['user']['id']], 'users');
            $this->session->set_userdata('users', $g_admin);
        } else {
            redirect('/dang-nhap/');
        }
    }
    public function account()
    {
        if (check_role() == 5 || check_role() == 4 || check_role() == 3  || check_role() == 0) {
            set_status_header(404);
            return $this->load->view('errors/html/error_role');
        } else {
            $data['list'] = $this->Madmin->get_list('', 'users');
            $data['canonical'] = base_url('laoi-du-an/');
            $data['meta_title'] = 'Loại dự án';
            $data['content'] = 'account/account';
            $data['list_js'] = [
                'sweetalert.min.js',
                'jquery.validate.min.js',
                'account/account.js',
            ];
            $data['list_css'] = [
                'sweetalert.css',
                'account/account.css',
            ];
            return $this->load->view('index', $data);
        }
    }
    public function add_user()
    {
        if (check_role() == 5 || check_role() == 4 || check_role() == 3 || check_role() == 0) {
            $response = [
                'status' => 0,
                'msg' => 'Không có quyền thao tác'
            ];
        } else {
            $data['username'] = $username =  $this->input->post('username');
            $data['name'] = $this->input->post('name');
            $data['password'] = md5($this->input->post('password'));
            $data['phone'] = $this->input->post('phone');
            $data['email'] = $this->input->post('email');
            $data['role'] = $this->input->post('role');
            $data['status'] = $this->input->post('status');
            $data['created_at'] = time();
            $data['updated_at'] = time();
            $check = $this->Madmin->get_by(['username' => $username], 'users');
            if ($check == null) {
                $insert = $this->Madmin->insert($data, 'users');
                $response = [
                    'status' => 1,
                    'msg' => 'Thành công'
                ];
            } else {
                $response = [
                    'status' => 0,
                    'msg' => 'Tên đăng nhập đã tồn tại'
                ];
            }
        }
        echo json_encode($response);
    }
    public function edit_user()
    {
        if (check_role() == 5 || check_role() == 4 || check_role() == 3 || check_role() == 0) {
            $response = [
                'status' => 0,
                'msg' => 'Không có quyền thao tác'
            ];
        } else {
            $id = $this->input->post('id');
            $check_id = $this->Madmin->get_by(['id' => $id], 'users');
            if ($check_id == null || $check_id['role'] <= $_SESSION['user']['role']) {
                $response = [
                    'status' => 0,
                    'msg' => 'Bạn không có quyền thao tác'
                ];
            } else {
                $data['username'] = $username =  $this->input->post('username');
                $data['name'] = $this->input->post('name');
                $pass = $this->input->post('password');
                $data['phone'] = $this->input->post('phone');
                $data['email'] = $this->input->post('email');
                $data['role'] = $this->input->post('role');
                $data['status'] = $this->input->post('status');
                $data['updated_at'] = time();
                if ($pass != null && $pass != '') {
                    $data['password'] = md5($pass);
                }
                $check = $this->Madmin->get_by(['username' => $username, 'id !=' => $id], 'users');
                if ($check == null) {
                    $update = $this->Madmin->update(['id' => $id], $data, 'users');
                    $response = [
                        'status' => 1,
                        'msg' => 'Thành công'
                    ];
                } else {
                    $response = [
                        'status' => 0,
                        'msg' => 'Tên đăng nhập đã tồn tại'
                    ];
                }
            }
        }
        echo json_encode($response);
    }
    public function get_user()
    {
        if (check_role() == 5 || check_role() == 4 || check_role() == 3 || check_role() == 0) {
            $response = [
                'status' => 0,
                'msg' => 'Không có quyền thao tác'
            ];
        } else {
            $id = $this->input->post('id');
            $user = $this->Madmin->get_by(['id' => $id], 'users');
            if ($user != null) {
                $response = [
                    'status' => 1,
                    'user' => $user
                ];
            } else {
                $response = [
                    'status' => 0,
                    'msg' => 'Tài khoản không tồn tại'
                ];
            }
        }
        echo json_encode($response);
    }
}
