<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Job extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Madmin');
        $this->load->database();
        $this->load->helper(['url', 'func_helper', 'images']);
        $this->load->library(['session', 'pagination311', 'upload']);
        if (admin()) {
            $g_admin = $this->Madmin->get_by(['id' => $_SESSION['user']['id']], 'users');
            $this->session->set_userdata('users', $g_admin);
        } else {
            redirect('/dang-nhap/');
        }
    }
    public function ctv_job()
    {
        if (check_role() == 5) {
            $id = $_SESSION['user']['id'];
            $ctv_jobs = $this->Madmin->query_sql("SELECT ctv_jobs.*,website,file,job_type,note_ctv,price,punish,jobs.info as job_info FROM ctv_jobs 
        JOIN projects On projects.id = ctv_jobs.project_id 
        JOIN jobs On jobs.id = ctv_jobs.job_id 
        WHERE ctv_jobs.ctv= $id");
            $data['ctv_jobs'] = $ctv_jobs;
            $data['canonical'] = base_url('cong-viec-cong-tac-vien/');
            $data['meta_title'] = 'Công việc cộng tác viên';
            $data['content'] = 'jobs/ctv';
            $data['list_js'] = [
                'job/ctv.js',
            ];
            $data['list_css'] = [
                'job/ctv.css'
            ];
            return $this->load->view('index', $data);
        } else {
            set_status_header(404);
            return $this->load->view('errors/html/error_role');
        }
    }
    public function qa_job()
    {
        if (check_role() == 4) {
            $id = $_SESSION['user']['id'];
            $jobs = $this->Madmin->query_sql("SELECT jobs.*,website,file,users.name as name_author FROM jobs
        JOIN users ON users.id = jobs.author 
        JOIN projects ON projects.id = jobs.project_id 
        WHERE jobs.status_qa= 1");
            $data['jobs'] = $jobs;
            $data['canonical'] = base_url('cong-viec-cong-tac-vien/');
            $data['meta_title'] = 'Công việc cộng tác viên';
            $data['content'] = 'jobs/qa';
            $data['list_js'] = [
                'job/qa.js',
            ];
            $data['list_css'] = [
                'job/qa.css'
            ];
            return $this->load->view('index', $data);
        } else {
            set_status_header(404);
            return $this->load->view('errors/html/error_role');
        }
    }
    public function index_job()
    {
        if (check_role() == 3) {
            $id = $_SESSION['user']['id'];
            $project = $this->Madmin->query_sql("SELECT * FROM projects WHERE status_index= 1");
            $data['project'] = $project;
            $data['canonical'] = base_url('cong-viec-cong-tac-vien/');
            $data['meta_title'] = 'Công việc cộng tác viên';
            $data['content'] = 'jobs/index';
            $data['list_js'] = [
                'job/index.js',
            ];
            $data['list_css'] = [
                'job/index.css'
            ];
            return $this->load->view('index', $data);
        } else {
            set_status_header(404);
            return $this->load->view('errors/html/error_role');
        }
    }
    public function change_ctv_job()
    {
        if (check_role() != 5) {
            $response = [
                'status' => 0,
                'msg' => 'Không có quyền thao tác'
            ];
        } else {
            $time = time();
            $id_u = $_SESSION['user']['id'];
            $id =  $this->input->post('id');
            $data['status'] = 1;
            $data['completion_time'] = $time;
            $check = $this->Madmin->get_by(['id' => $id, 'ctv' => $id_u, 'status' => 0], 'ctv_jobs');
            if ($check != null) {
                $check_qa = $this->Madmin->get_by(['id' => $check['job_id'], 'status' => 0, 'status_qa' => 0], 'jobs');
                if ($check_qa == null) {
                    $data['status_qa_check'] = 2;
                } else { // nếu không cần QA check
                    $data_job['completion_time'] = $time;
                    $data_job['status'] = 1;
                    $update_job = $this->Madmin->update(['id' => $check['job_id']], $data_job, 'jobs');
                }
                $update = $this->Madmin->update(['id' => $id], $data, 'ctv_jobs');
                $count_job = $this->Madmin->num_rows(['id' => $check['project_id'], 'status' => 1], 'jobs'); // kiểm tra xem trong dự án còn job nào chưa hoàn thành không
                if ($count_job == 0) {
                    $check_index = $this->Madmin->query_sql_row("SELECT id,status_index FROM projects WHERE status= 2 AND id = {$check['project_id']}"); // check dự án cần index không
                    if ($check_index['status_index'] == 1) { // nếu cần check index
                        $update_index = $this->Madmin->update(['id' => $check['project_id']], ['check_index' => 3], 'projects'); //chuyển qua index check
                    } else if ($check_index['status_index'] == 0) {
                        $update_index = $this->Madmin->update(['id' => $check['project_id']], ['check_index' => 1, 'status' => 1, 'time_end' => $time], 'projects'); // hoàn thành công việc
                    }
                }
                $response = [
                    'status' => 1,
                    'msg' => 'Thành công'
                ];
            } else {
                $response = [
                    'status' => 0,
                    'msg' => 'Công việc không tồn tại. Vui lòng kiểm tra lại'
                ];
            }
        }
        echo json_encode($response);
    }
    public function change_check_replly()
    {
        if (check_role() != 5) {
            $response = [
                'status' => 0,
                'msg' => 'Không có quyền thao tác'
            ];
        } else {
            $id_u = $_SESSION['user']['id'];
            $id =  $this->input->post('id');
            $data['check_replly'] = $value = $this->input->post('value');
            $check = $this->Madmin->get_by(['id' => $id, 'ctv' => $id_u, 'check_replly' => 1], 'ctv_jobs');
            if ($check != null) {
                if ($value == 3) {
                    $data['status_qa_check'] = 3;
                }
                $update = $this->Madmin->update(['id' => $id], $data, 'ctv_jobs');
                $response = [
                    'status' => 1,
                    'msg' => 'Thành công'
                ];
            } else {
                $response = [
                    'status' => 0,
                    'msg' => 'Công việc không tồn tại. Vui lòng kiểm tra lại'
                ];
            }
        }
        echo json_encode($response);
    }
    public function change_text_qa()
    {
        if (check_role() != 4) {
            $response = [
                'status' => 0,
                'msg' => 'Không có quyền thao tác'
            ];
        } else {
            $id_u = $_SESSION['user']['id'];
            $id =  $this->input->post('id');
            $name =  $this->input->post('name');
            $data[$name] = $this->input->post('value');
            $data['qa_id'] = $id_u;
            $check = $this->Madmin->get_by(['id' => $id], 'jobs');
            if ($check != null) {
                $check_2 = $this->Madmin->get_by(['job_id' => $id], 'ctv_jobs');
                if ($check_2 != null) {
                    $insert = $this->Madmin->update(['job_id' => $id], $data, 'ctv_jobs');
                    $response = [
                        'status' => 1,
                        'msg' => 'Thành công'
                    ];
                } else {
                    $response = [
                        'status' => 0,
                        'msg' => 'Công việc chưa được giao. Vui lòng kiểm tra lại'
                    ];
                }
            } else {
                $response = [
                    'status' => 0,
                    'msg' => 'Công việc không tồn tại. Vui lòng kiểm tra lại'
                ];
            }
        }
        echo json_encode($response);
    }
    public function change_job_qa()
    {
        if (check_role() != 4) {
            $response = [
                'status' => 0,
                'msg' => 'Không có quyền thao tác'
            ];
        } else {
            $id_u = $_SESSION['user']['id'];
            $id =  $this->input->post('id');
            $name =  $this->input->post('name');
            $data[$name] = $this->input->post('value');
            $check = $this->Madmin->get_by(['id' => $id], 'jobs');
            if ($check != null) {
                $check_2 = $this->Madmin->get_by("job_id = $id AND status = 1 AND status_qa_check !=0 AND status_qa_check != 1 AND (qa_id is null OR qa_id = $id_u ) ", 'ctv_jobs');
                if ($check_2 != null) {
                    $update = $this->Madmin->update(['id' => $id], $data, 'jobs');
                    $response = [
                        'status' => 1,
                        'msg' => 'Thành công'
                    ];
                } else {
                    $response = [
                        'status' => 0,
                        'msg' => 'Công việc chưa được giao. Vui lòng kiểm tra lại'
                    ];
                }
            } else {
                $response = [
                    'status' => 0,
                    'msg' => 'Công việc không tồn tại. Vui lòng kiểm tra lại'
                ];
            }
        }
        echo json_encode($response);
    }
    public function change_status_job_qa()
    {
        if (check_role() != 4) {
            $response = [
                'status' => 0,
                'msg' => 'Không có quyền thao tác'
            ];
        } else {
            $id_u = $_SESSION['user']['id'];
            $id =  $this->input->post('id');
            $data['status_qa_check'] = $status_qa_check = $this->input->post('value');
            $data['time_qa_check'] = time();
            $data['check_replly'] = 1;
            $check = $this->Madmin->get_by(['id' => $id], 'jobs');
            if ($check != null) {
                $check_2 = $this->Madmin->get_by("job_id = $id AND status = 1 AND status_qa_check !=0 AND status_qa_check != 1 AND (qa_id is null OR qa_id = $id_u ) ", 'ctv_jobs');
                if ($check_2 != null) {
                    $update = $this->Madmin->update(['job_id' => $id], $data, 'ctv_jobs');
                    $response = [
                        'status' => 1,
                        'msg' => 'Thành công'
                    ];
                } else {
                    $response = [
                        'status' => 0,
                        'msg' => 'Công việc chưa được giao. Vui lòng kiểm tra lại'
                    ];
                }
            } else {
                $response = [
                    'status' => 0,
                    'msg' => 'Công việc không tồn tại. Vui lòng kiểm tra lại'
                ];
            }
        }
        echo json_encode($response);
    }
    public function change_status_job_index()
    {
        if (check_role() != 3) {
            $response = [
                'status' => 0,
                'msg' => 'Không có quyền thao tác'
            ];
        } else {
            $id_u = $_SESSION['user']['id'];
            $id =  $this->input->post('id');
            $data['check_index'] = $value = $this->input->post('value');
            $data['time_index'] = time();
            $data['user_check_index'] = $id_u;
            $check = $this->Madmin->get_by(['id' => $id, 'status' => 2, 'status_index' => 1], 'projects');
            if ($check != null) {
                if($value == 1){
                    $data['status'] = 1;
                    $data['time_end'] =time();
                }
                $update = $this->Madmin->update(['id' => $id], $data, 'projects');
                $response = [
                    'status' => 1,
                    'msg' => 'Thành công'
                ];
            } else {
                $response = [
                    'status' => 0,
                    'msg' => 'Dự án không tồn tại. Vui lòng kiểm tra lại'
                ];
            }
        }
        echo json_encode($response);
    }
}
