<div class="content">
    <div class="content_about body_width">
        <div class="top_bxh">
            <div class="left_bxh">
                <p class="name_top active" data-id="1">Game Mới</p>
                <p class="name_top" data-id="2">Game Hay</p>
                <p class="name_top" data-id="3">Game Hot</p>
            </div>
            <div class="right_bxh">
                <div class="box_new box_top">
                    <img src="/images/blog/Revelation-Thien-Du-22-75x75.jpg" alt="">
                    <img src="/images/blog/De-Quoc-Quat-Khoi-mobile-1-75x75.jpg" alt="">
                    <img src="/images/blog/vo-lam-nhan-hiep-e1668508665926-75x75.jpg" alt="">
                    <img src="/images/blog/thuc-tinh-than-thu-e1667965967675-75x75.jpg" alt="">
                    <img src="/images/blog/thien-ha-anh-hung-3q-7-75x75.jpg" alt="">
                    <img src="/images/blog/thien-long-truyen-ky-75x75.png" alt="">
                    <img src="/images/blog/stickman-afk-75x75.png" alt="">
                    <img src="/images/blog/tam-quoc-chi-slg-75x75.jpg" alt="">
                    <img src="/images/blog/vo-lam-nhan-hiep-e1668508665926-75x75.jpg" alt="">
                    <img src="/images/blog/ma-than-lu-bo-75x75.jpg" alt="">
                    <img src="/images/blog/dau-tuong-vng-3-75x75.jpg" alt="">
                    <img src="/images/blog/thuong-co-chi-vuong-75x75.jpg" alt="">
                    <img src="/images/blog/giang-ho-ky-hiep-3d-75x75.jpg" alt="">
                    <img src="/images/blog/ninja-lang-la-truyen-ky-1-75x75.png" alt="">
                    <img src="/images/blog/loan-chien-mobile-funzy-motgame-75x75.jpg" alt="">
                    <img src="/images/blog/Final_Fantasy_VII_Remake_icon.jpg" alt="">
                    <img src="/images/blog/lien-minh-bao-boi-1-75x75.jpg" alt="">
                    <img src="/images/blog/omg-3q-thumb-75x75.jpg" alt="">
                    <img src="/images/blog/thieu-nien-anh-hung-75x75.jpg" alt="">
                    <img src="/images/blog/DGPAL-icon-75x75.jpg" alt="">
                </div>
                <div class="box_new box_hay" style="display: none;">
                    <img src="/images/blog/DGPAL-icon-75x75.jpg" alt="">
                    <img src="/images/blog/dau-la-vng-1-75x75.jpg" alt="">
                    <img src="/images/blog/unnamed.jpg" alt="">
                    <img src="/images/blog/Yakuza_Like_a_Dragon_ho_so_game_8.jpg" alt="">
                    <img src="/images/blog/diablo-immortal-icon.jpg" alt="">
                    <img src="/images/blog/Diablo_IV_icon.jpg" alt="">
                    <img src="/images/blog/Ruined_King_logo.jpg" alt="">
                    <img src="/images/blog/CWicon_1.jpg" alt="">
                    <img src="/images/blog/MW2019_icon_1.jpg" alt="">
                    <img src="/images/blog/assassincreed-valhalla-icon.jpg" alt="">
                    <img src="/images/blog/marvels_spider-man_miles_morales_ho_so_game_8.jpg" alt="">
                    <img src="/images/blog/Little_Nightmares_II_ho_so_game_2.jpg" alt="">
                    <img src="/images/blog/overwatch-icon.jpg" alt="">
                    <img src="/images/blog/Final_Fantasy_VII_Remake_icon.jpg" alt="">
                    <img src="/images/blog/Observer_Icon.jpg" alt="">
                    <img src="/images/blog/Hitman_3_ho_so_game_Icon.jpg" alt="">
                    <img src="/images/blog/thu_vien_game_hyrule_warriors_age_of_calamity.jpg" alt="">
                    <img src="/images/blog/thu_vien_game_call_of_the_sea.jpg" alt="">
                    <img src="/images/blog/icon.jpg" alt="">
                    <img src="/images/blog/Black_Myth_Wukong_ICN.jpg" alt="">
                </div>
                <div class="box_new box_hot" style="display: none;">
                    <img src="/images/blog/vltk-max-75x75.jpg" alt="">
                    <img src="/images/blog/DGPAL-icon-75x75.jpg" alt="">
                    <img src="/images/blog/73021282_111690493595271_2683900968503869440_n_1.jpg" alt="">
                    <img src="/images/blog/motgame_garena_lien_quan_mobile_logo.jpg" alt="">
                    <img src="/images/blog/dau-truong-chan-ly-icon-02_1.jpg" alt="">
                    <img src="/images/blog/motgame_huyen_thoai_runeterra_logo.jpg" alt="">
                    <img src="/images/blog/motgame_VALORANT_logo.jpg" alt="">
                    <img src="/images/blog/motgame_logo_garena_free_fire.jpg" alt="">
                    <img src="/images/blog/dota-2-icon.jpg" alt="">
                    <img src="/images/blog/pubg-mobile-icon.jpg" alt="">
                </div>
            </div>
        </div>
        <div class="bottom_bxh">
            <div class="box_bottom">
                <div class="title_bottom title_bottom_1">
                    <img src="/images/blog/hot.png" alt="game hot">
                    <p>Game nhiều người chơi</p>
                </div>
                <div class="list_bottom">
                    <div class="this_bottom">
                        <p class="number_bottom">1</p>
                        <p class="name_game">One Punch Man The Strongest</p>
                    </div>
                    <div class="this_bottom">
                        <p class="number_bottom">2</p>
                        <p class="name_game">Chiu Chiu Tam Quốc</p>
                    </div>
                    <div class="this_bottom">
                        <p class="number_bottom">3</p>
                        <p class="name_game">Tam Anh Thủ Thành</p>
                    </div>
                    <div class="this_bottom">
                        <p class="number_bottom">4</p>
                        <p class="name_game">Tân OMG3Q VNG</p>
                    </div>
                    <div class="this_bottom">
                        <p class="number_bottom">5</p>
                        <p class="name_game">Dota 2</p>
                    </div>
                    <div class="this_bottom">
                        <p class="number_bottom">6</p>
                        <p class="name_game">Kỷ Nguyên Huyền Thoại</p>
                    </div>
                    <div class="this_bottom">
                        <p class="number_bottom">7</p>
                        <p class="name_game">Garena Liên Quân Mobile</p>
                    </div>
                    <div class="this_bottom">
                        <p class="number_bottom">8</p>
                        <p class="name_game">Kỷ Nguyên Triệu Hồi</p>
                    </div>
                    <div class="this_bottom">
                        <p class="number_bottom">9</p>
                        <p class="name_game">Võ Lâm Truyền Kỳ 1 Mobile</p>
                    </div>
                    <div class="this_bottom">
                        <p class="number_bottom">10</p>
                        <p class="name_game">Genshin Impact</p>
                    </div>
                </div>
            </div>
            <div class="box_bottom">
                <div class="title_bottom title_bottom_2">
                    <img src="/images/blog/xuhuong.png" alt="game xu hướng">
                    <p>Game tạo xu hướng</p>
                </div>
                <div class="list_bottom">
                    <div class="this_bottom">
                        <p class="number_bottom">1</p>
                        <p class="name_game">D.G.Pals</p>
                    </div>
                    <div class="this_bottom">
                        <p class="number_bottom">2</p>
                        <p class="name_game">Yêu Linh Giới VGP</p>
                    </div>
                    <div class="this_bottom">
                        <p class="number_bottom">3</p>
                        <p class="name_game">Gọi Ta Đại Chưởng Quỹ</p>
                    </div>
                    <div class="this_bottom">
                        <p class="number_bottom">4</p>
                        <p class="name_game">Huyền Thoại Runeterra</p>
                    </div>
                    <div class="this_bottom">
                        <p class="number_bottom">5</p>
                        <p class="name_game">Garena Liên Quân Mobile</p>
                    </div>
                    <div class="this_bottom">
                        <p class="number_bottom">6</p>
                        <p class="name_game">Đấu Trường Chân Lý</p>
                    </div>
                    <div class="this_bottom">
                        <p class="number_bottom">7</p>
                        <p class="name_game">Valorant</p>
                    </div>
                    <div class="this_bottom">
                        <p class="number_bottom">8</p>
                        <p class="name_game">Garena Free Fire</p>
                    </div>
                    <div class="this_bottom">
                        <p class="number_bottom">9</p>
                        <p class="name_game">Liên Minh Huyền Thoại</p>
                    </div>
                    <div class="this_bottom">
                        <p class="number_bottom">10</p>
                        <p class="name_game">Liên Minh Tốc Chiến</p>
                    </div>
                </div>
            </div>
            <div class="box_bottom">
                <div class="title_bottom title_bottom_3">
                    <img src="/images/blog/tim.png" alt="game yêu thích">
                    <p>Game được yêu thích nhất</p>
                </div>
                <div class="list_bottom">
                    <div class="this_bottom">
                        <p class="number_bottom">1</p>
                        <p class="name_game">Bộ Lạc H5</p>
                    </div>
                    <div class="this_bottom">
                        <p class="number_bottom">2</p>
                        <p class="name_game">Đại Tỷ 3Q</p>
                    </div>
                    <div class="this_bottom">
                        <p class="number_bottom">3</p>
                        <p class="name_game">Subverse</p>
                    </div>
                    <div class="this_bottom">
                        <p class="number_bottom">4</p>
                        <p class="name_game">Little Nightmares II</p>
                    </div>
                    <div class="this_bottom">
                        <p class="number_bottom">5</p>
                        <p class="name_game">Spider-Man: Miles Morales</p>
                    </div>
                    <div class="this_bottom">
                        <p class="number_bottom">6</p>
                        <p class="name_game">Call of Duty: Black Ops Cold War</p>
                    </div>
                    <div class="this_bottom">
                        <p class="number_bottom">7</p>
                        <p class="name_game">Call of Duty: Modern Warfare</p>
                    </div>
                    <div class="this_bottom">
                        <p class="number_bottom">8</p>
                        <p class="name_game">Yakuza: Like a Dragon</p>
                    </div>
                    <div class="this_bottom">
                        <p class="number_bottom">9</p>
                        <p class="name_game">Cyberpunk 2077</p>
                    </div>
                    <div class="this_bottom">
                        <p class="number_bottom">10</p>
                        <p class="name_game">Assassins Creed Valhalla</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>