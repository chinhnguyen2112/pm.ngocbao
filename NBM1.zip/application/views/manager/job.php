<div class="main">
    <div class="main_content">
        <div class="main_top">
            <div class="add_project">
                <a href="/them-cong-viec/">
                    <div class="img_add_project"><img src="/images/add_red.svg" alt="Thêm dự án"></div>
                    <p>Thêm công việc</p>
                </a>
            </div>
            <div class="right_top">
                <div class="money">
                    <p>$ 700.000</p>
                </div>
                <div class="profile">
                    <img src="/images/avatar.png" alt="avatar" class="avatar">
                    <div class="box_profile">
                        <p class="name_role">Member</p>
                        <p class="name">Ilay Riegrow <img src="/images/arrow.svg" alt="Thêm dự án"></p>
                        <div class="nav_profile">
                            <ul>
                                <li><a href="#"><img src="/images/avatar.svg" alt="Thông tin cá nhân"> Thông tin cá nhân</a></li>
                                <li><a href="#"><img src="/images/pass.svg" alt="Đổi mật khẩu"> Đổi mật khẩu</a></li>
                                <li><a href="#"><img src="/images/logout.svg" alt="Đăng xuất"> Đăng xuất</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="main_filter bg_main">
            <div class="title_filter">
                <div class="title_filter_left">
                    <img src="/images/filter.svg" alt="Bộ lọc">
                    <p>Bộ lọc</p>
                </div>
                <div class="show_filter">
                    <p>Thu gọn</p> <img src="/images/2_arrow.svg" alt="Thu gọn">
                </div>
            </div>
            <div class="list_filter">
                <div class="this_filter">
                    <input type="text" name="names" id="ids" placeholder="Mã dự án">
                </div>
                <div class="this_filter">
                    <input type="date" name="names" id="ids" placeholder="Thời gian nhận việc">
                </div>
                <div class="this_filter">
                    <input type="date" name="names" id="ids" placeholder="Thời gian tạo dự án">
                </div>
                <div class="this_filter">
                    <select name="names" id="ids">
                        <option value="0">P.I.C dự án</option>
                    </select>
                </div>
                <div class="this_filter">
                    <select name="names" id="ids">
                        <option value="0">Khách hàng</option>
                    </select>
                </div>
                <div class="this_filter">
                    <select name="names" id="ids">
                        <option value="0">Trạng thái công nợ</option>
                    </select>
                </div>
                <div class="this_filter">
                    <select name="names" id="ids">
                        <option value="0">Website dự án</option>
                    </select>
                </div>
                <div class="this_filter">
                    <select name="names" id="ids">
                        <option value="0">Trạng thái triển khai</option>
                    </select>
                </div>
                <div class="this_filter">
                    <input type="date" name="names" id="ids" placeholder="Thời gian tạo triển khai">
                </div>
                <div class="this_filter">
                    <input type="date" name="names" id="ids" placeholder="Thời gian hoàn thành">
                </div>
                <div class="this_filter">
                    <input type="date" name="names" id="ids" placeholder="Thời gian hủy">
                </div>
                <div class="this_filter">
                    <input type="date" name="names" id="ids" placeholder="Thời gian tạm dừng">
                </div>
                <div class="this_filter">
                    <select name="names" id="ids">
                        <option value="0">Trạng thái bàn giao</option>
                    </select>
                </div>
                <div class="this_filter">
                    <select name="names" id="ids">
                        <option value="0">Loại dự án</option>
                    </select>
                </div>
                <div class="this_filter">
                    <input type="date" name="names" id="ids" placeholder="Deadline dự án">
                </div>
                <div class="this_filter">
                    <select name="names" id="ids">
                        <option value="0">Tiến độ phân dự án</option>
                    </select>
                </div>
                <div class="this_filter">
                    <select name="names" id="ids">
                        <option value="0">Trạng thái công tác viên</option>
                    </select>
                </div>
                <div class="this_filter">
                    <input type="date" name="names" id="ids" placeholder="Thời gian cập nhật trạng thái CTV">
                </div>
                <div class="this_filter">
                    <select name="names" id="ids">
                        <option value="0">Trạng thái QA</option>
                    </select>
                </div>
                <div class="this_filter">
                    <input type="date" name="names" id="ids" placeholder="Thời gian cập nhật QA">
                </div>
                <div class="this_filter">
                    <select name="names" id="ids">
                        <option value="0">Trạng index</option>
                    </select>
                </div>
                <div class="this_filter">
                    <input type="date" name="names" id="ids" placeholder="Thời gian cập nhật trạng thái index">
                </div>
            </div>
        </div>
        <div class="main_filter bg_main">
            <div class="title_project">
                <div class="box_btn_project" style="display: none;">
                    <p class="btn_project btn_project_cancel">Xóa</p>
                </div>
            </div>
            <div class="box_project">
                <div class="project">
                    <table border="1" cellpadding="2" cellspacing="2">
                        <thead>
                            <tr>
                                <th rowspan="2">
                                    <div><input type="checkbox" class="check_full" name="check_full" id=""></div>
                                </th>
                                <th rowspan="2">
                                    <div>Mã công việc</div>
                                </th>
                                <th rowspan="2">
                                    <div>Thông tin công việc</div>
                                </th>
                                <th rowspan="2">
                                    <div>Loại công việc</div>
                                </th>
                                <th rowspan="2">
                                    <div>Người tạo</div>
                                </th>
                                <th rowspan="2">
                                    <div>Thời gian tạo</div>
                                </th>
                                <th rowspan="2">
                                    <div>Website</div>
                                </th>
                                <th rowspan="2">
                                    <div>Chi phí công việc</div>
                                </th>
                                <th rowspan="2">
                                    <div>Phạt</div>
                                </th>
                                <th rowspan="2">
                                    <div>Chi phí cuối</div>
                                </th>
                                <th colspan="6" class="th_col">CTV</th>
                                <th colspan="4" class="th_col">QA</th>
                                <th rowspan="2">
                                    <div>Tiến độ công việc chung</div>
                                </th>
                                <th rowspan="2">
                                    <div>Thời gian hoàn thành</div>
                                </th>
                                <th rowspan="2">
                                    <div>Mức độ ưu tiên</div>
                                </th>
                                <th rowspan="2">
                                    <div>Ghi chú QA</div>
                                </th>
                                <th rowspan="2">
                                    <div>Ghi chú cho CTV</div>
                                </th>
                                <th rowspan="2">
                                    <div>Ghi chú</div>
                                </th>
                            </tr>
                            <tr>
                                <th>CTV thực hiện</th>
                                <th>Deadline CTV</th>
                                <th>Tiến độ CTV</th>
                                <th>Thời gian triển khai</th>
                                <th>Thời gian hoàn thành</th>
                                <th>Xác nhận duyệt</th>
                                <th>QA thực hiện</th>
                                <th>Tiến độ QA</th>
                                <th>Thời gian duyệt</th>
                                <th>Đánh giá</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($jobs as $val) {  ?>
                                <tr>
                                    <td><input type="checkbox" class="check_i" name="check_i" id=""></td>
                                    <td><?= $val['code'] ?></td>
                                    <td><?= $val['info'] ?></td>
                                    <td><?= $val['name_job_type'] ?></td>
                                    <td><?= $val['name_author'] ?> - <?= role($val['author']) ?></td>
                                    <td><?= date('H:i:s d/m/Y', $val['created_at']) ?></td>
                                    <td><?= $val['website'] ?></td>
                                    <td><?= number_format($val['price']) ?></td>
                                    <td><?= number_format($val['punish']) ?></td>
                                    <td><?= number_format($val['price'] - $val['punish']) ?></td>
                                    <td><?= $val['name_ctv'] ?></td>
                                    <td><?php if ($val['deadline_ctv'] > 0) {
                                            echo date('H:i:s d/m/Y', $val['deadline_ctv']);
                                        } else { ?>Chưa cập nhật<?php } ?></td>
                                    <td><?= status_ctv_job($val['status_ctv']) ?></td>
                                    <td><?php if ($val['time_ctv_job'] > 0) {
                                            echo date('H:i:s d/m/Y', $val['time_ctv_job']);
                                        } else { ?>Chưa cập nhật<?php } ?></td>
                                    <td><?php if ($val['completion_ctv_job'] > 0) {
                                            echo date('H:i:s d/m/Y', $val['completion_ctv_job']);
                                        } else { ?>Chưa cập nhật<?php } ?></td>
                                    <td><?= ctv_check_status_qa($val['ctv_check_replly']); ?></td>
                                    <td><?= $val['qa_name'] ?></td>
                                    <td><?= ($val['status_qa'] == 1)? status_qa_check($val['status_qa_check']) : "Không cần QA check"; ?></td>
                                    <td><?= ($val['status_qa'] == 1 && $val['time_qa_check'] > 0)? date('H:i:s d/m/Y', $val['time_qa_check']) : "--Thời gian duyệt--"; ?></td>
                                    <td><?= ($val['status_qa'] == 1)? $val['content_qa_check'] : "--Đánh giá--"; ?></td>
                                    <td><?= status_job($val['status']); ?></td>
                                    <td><?= date('H:i:s', $val['completion_time']) ?><br><?= date('d/m/Y', $val['completion_time']) ?></td>
                                    <td><?= $val['z_index'] ?></td>
                                    <td><?= $val['note_qa'] ?></td>
                                    <td><?= $val['note_ctv'] ?></td>
                                    <td><?= $val['note'] ?></td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
                <div class="list_btn_project">
                    <p class="save_project">Lưu</p>
                    <p class="reset_project">Hủy</p>
                </div>
            </div>
        </div>
    </div>
</div>