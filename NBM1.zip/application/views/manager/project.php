<div class="main">
    <div class="main_content">
        <div class="main_top">
            <div class="add_project">
                <a href="/them-du-an/">
                    <div class="img_add_project"><img src="/images/add_red.svg" alt="Thêm dự án"></div>
                    <p>Thêm dự án</p>
                </a>
            </div>
            <div class="right_top">
                <div class="money">
                    <p>$ 700.000</p>
                </div>
                <div class="profile">
                    <img src="/images/avatar.png" alt="avatar" class="avatar">
                    <div class="box_profile">
                        <p class="name_role">Member</p>
                        <p class="name">Ilay Riegrow <img src="/images/arrow.svg" alt="Thêm dự án"></p>
                        <div class="nav_profile">
                            <ul>
                                <li><a href="#"><img src="/images/avatar.svg" alt="Thông tin cá nhân"> Thông tin cá nhân</a></li>
                                <li><a href="#"><img src="/images/pass.svg" alt="Đổi mật khẩu"> Đổi mật khẩu</a></li>
                                <li><a href="#"><img src="/images/logout.svg" alt="Đăng xuất"> Đăng xuất</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="main_filter bg_main">
            <div class="title_filter">
                <div class="title_filter_left">
                    <img src="/images/filter.svg" alt="Bộ lọc">
                    <p>Bộ lọc</p>
                </div>
                <div class="show_filter">
                    <p>Thu gọn</p> <img src="/images/2_arrow.svg" alt="Thu gọn">
                </div>
            </div>
            <div class="list_filter">
                <div class="this_filter">
                    <input type="text" name="names" id="ids" placeholder="Mã dự án">
                </div>
                <div class="this_filter">
                    <input type="date" name="names" id="ids" placeholder="Thời gian nhận việc">
                </div>
                <div class="this_filter">
                    <input type="date" name="names" id="ids" placeholder="Thời gian tạo dự án">
                </div>
                <div class="this_filter">
                    <select name="names" id="ids">
                        <option value="0">P.I.C dự án</option>
                    </select>
                </div>
                <div class="this_filter">
                    <select name="names" id="ids">
                        <option value="0">Khách hàng</option>
                    </select>
                </div>
                <div class="this_filter">
                    <select name="names" id="ids">
                        <option value="0">Trạng thái công nợ</option>
                    </select>
                </div>
                <div class="this_filter">
                    <select name="names" id="ids">
                        <option value="0">Website dự án</option>
                    </select>
                </div>
                <div class="this_filter">
                    <select name="names" id="ids">
                        <option value="0">Trạng thái triển khai</option>
                    </select>
                </div>
                <div class="this_filter">
                    <input type="date" name="names" id="ids" placeholder="Thời gian tạo triển khai">
                </div>
                <div class="this_filter">
                    <input type="date" name="names" id="ids" placeholder="Thời gian hoàn thành">
                </div>
                <div class="this_filter">
                    <input type="date" name="names" id="ids" placeholder="Thời gian hủy">
                </div>
                <div class="this_filter">
                    <input type="date" name="names" id="ids" placeholder="Thời gian tạm dừng">
                </div>
                <div class="this_filter">
                    <select name="names" id="ids">
                        <option value="0">Trạng thái bàn giao</option>
                    </select>
                </div>
                <div class="this_filter">
                    <select name="names" id="ids">
                        <option value="0">Loại dự án</option>
                    </select>
                </div>
                <div class="this_filter">
                    <input type="date" name="names" id="ids" placeholder="Deadline dự án">
                </div>
                <div class="this_filter">
                    <select name="names" id="ids">
                        <option value="0">Tiến độ phân dự án</option>
                    </select>
                </div>
                <div class="this_filter">
                    <select name="names" id="ids">
                        <option value="0">Trạng thái công tác viên</option>
                    </select>
                </div>
                <div class="this_filter">
                    <input type="date" name="names" id="ids" placeholder="Thời gian cập nhật trạng thái CTV">
                </div>
                <div class="this_filter">
                    <select name="names" id="ids">
                        <option value="0">Trạng thái QA</option>
                    </select>
                </div>
                <div class="this_filter">
                    <input type="date" name="names" id="ids" placeholder="Thời gian cập nhật QA">
                </div>
                <div class="this_filter">
                    <select name="names" id="ids">
                        <option value="0">Trạng index</option>
                    </select>
                </div>
                <div class="this_filter">
                    <input type="date" name="names" id="ids" placeholder="Thời gian cập nhật trạng thái index">
                </div>
            </div>
        </div>
        <div class="main_filter bg_main">
            <div class="title_project">
                <div class="box_btn_project" style="display: none;">
                    <p class="btn_project btn_project_cancel">Xóa</p>
                </div>
            </div>
            <div class="box_project">
                <div class="project">
                    <table border="1" cellpadding="2" cellspacing="2">
                        <thead>
                            <tr>
                                <th rowspan="3">
                                    <div><input type="checkbox" class="check_full" name="check_full" id=""></div>
                                </th>
                                <th rowspan="3">
                                    <div>Mã dự án</div>
                                </th>
                                <th rowspan="3">
                                    <div>Thời gian tạo dự án</div>
                                </th>
                                <th rowspan="3">
                                    <div>P.I.C dự án</div>
                                </th>
                                <th rowspan="3">
                                    <div>Khách hàng</div>
                                </th>
                                <th rowspan="3">
                                    <div>Doanh thu</div>
                                </th>
                                <th rowspan="3">
                                    <div>Đã thu</div>
                                </th>
                                <th rowspan="3">
                                    <div>Công nợ</div>
                                </th>
                                <th rowspan="3">
                                    <div>Trạng thái công nợ</div>
                                </th>
                                <th rowspan="3">
                                    <div>Thời gian dục khách hàng</div>
                                </th>
                                <th colspan="5" class="th_col">Trạng thái triển khai</th>
                                <th rowspan="3">
                                    <div>Trạng thái bàn giao</div>
                                </th>
                                <th rowspan="3">
                                    <div>Website dự án</div>
                                </th>
                                <th rowspan="3">
                                    <div>Loại dự án</div>
                                </th>
                                <th rowspan="3">
                                    <div>Thông tin dự án</div>
                                </th>
                                <th rowspan="3">
                                    <div>Deadline dự án</div>
                                </th>
                                <th rowspan="3">
                                    <div>Tiến độ phân dự án</div>
                                </th>
                                <th colspan="9" class="th_col">Tiến độ dự án</th>
                                <th rowspan="3">
                                    <div>File dự án</div>
                                </th>
                                <th rowspan="3">
                                    <div>Chi phí thuê CTV</div>
                                </th>
                                <th rowspan="3">
                                    <div>CTV thực hiện dự án</div>
                                </th>
                                <th rowspan="3">
                                    <div>Ghi chú index</div>
                                </th>
                                <th rowspan="3">
                                    <div>Ghi chú</div>
                                </th>
                            </tr>
                            <tr>
                                <th rowspan="2" class="col_color">Trạng thái</th>
                                <th rowspan="2" class="col_color">Thời gian đang triển khai</th>
                                <th rowspan="2" class="col_color">Thời gian hoàn thành</th>
                                <th rowspan="2" class="col_color">Thời gian hủy dự án</th>
                                <th rowspan="2" class="col_color">Thời gian tạm dừng</th>
                                <th colspan="2">CTV</th>
                                <th colspan="3">QA</th>
                                <th colspan="4">Indexed</th>
                            </tr>
                            <tr>
                                <th>Trạng thái CTV</th>
                                <th>Thời gian cập nhật CTV</th>
                                <th>Người duyệt QA</th>
                                <th>Trạng thái QA</th>
                                <th>Thời gian cập nhật QA</th>
                                <th>Người duyệt Indexed</th>
                                <th>Trạng thái</th>
                                <th>Thời gian cập nhật</th>
                                <th>Tỉ lệ indexed</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($project as $val) {  ?>
                                <tr>
                                    <td><input type="checkbox" class="check_i" name="check_i" id=""></td>
                                    <td><?= project_id($val['id']) ?></td>
                                    <td><?= date('H:i:s d/m/Y', $val['created_at']) ?></td>
                                    <td><?= $val['name_author'] ?></td>
                                    <td><?= $val['customer'] ?></td>
                                    <td><?= number_format($val['revenue']) ?></td>
                                    <td><?php $money = fn_get_row('SUM(money) as money_sum', ['project_id' => $val['id'], 'bank_status' => 1], 'collect_money');
                                        echo number_format($money['money_sum']); ?></td>
                                    <td><?= number_format($val['revenue'] - $money['money_sum']) ?></td>
                                    <td><?= debt_status($val['debt_status']) ?></td>
                                    <td>Đã báo: 3 lần</td>
                                    <td><?= status_project($val['status']) ?></td>
                                    <td><?php if ($val['time_start'] > 0) {
                                            echo date('H:i:s d/m/Y', $val['time_start']);
                                        } else { ?>--Thời gian--<?php } ?></td>
                                    <td><?php if ($val['time_end'] > 0) {
                                            echo date('H:i:s d/m/Y', $val['time_end']);
                                        } else { ?>--Thời gian--<?php } ?></td>
                                    <td><?php if ($val['time_cancel'] > 0) {
                                            echo date('H:i:s d/m/Y', $val['time_cancel']);
                                        } else { ?>--Thời gian--<?php } ?></td>
                                    <td><?php if ($val['time_pause'] > 0) {
                                            echo date('H:i:s d/m/Y', $val['time_pause']);
                                        } else { ?>--Thời gian--<?php } ?></td>
                                    <td><?= handover_status($val['handover_status']) ?></td>
                                    <td><a href="<?= $val['website'] ?>"><?= $val['website'] ?></a></td>
                                    <td><?= $val['name_project_type'] ?></td>
                                    <td><?= $val['info'] ?></td>
                                    <td><?= date('H:i:s d/m/Y', $val['deadline']) ?></td>
                                    <td><?= project_division($val['ctv_job_count'], $val['job_count']) ?></td>
                                    <td><?php $num_ctv_job_success = fn_get_num(['project_id' => $val['id'], 'status' => 1], 'ctv_jobs');
                                        echo ctv_success($num_ctv_job_success, $val['job_count']); ?></td>
                                    <td><?= ($val['ctv_job_completion_time'] > 0) ? date('H:i:s d/m/Y', $val['ctv_job_completion_time']) : "--Thời gian--" ?></td>
                                    <td>Nguyễn Văn D</td>
                                    <td><?php $job_qa = fn_get_num(['project_id' => $val['id'], 'status_qa' => 1], 'jobs');
                                        $job_qa_success = fn_get_num(['project_id' => $val['id'], 'status' => 1], 'ctv_jobs');
                                        echo job_qa_success($job_qa_success, $job_qa); ?></td>
                                    <td><?= time_qa_check_new(['project_id' => $val['id'], 'status' => 1]); ?></td>
                                    <td><?php if ($val['status_index'] == 1 && $val['user_check_index'] > 0) {
                                            echo get_name($val['user_check_index']);
                                        } else {
                                            echo '--Người duyệt--';
                                        } ?></td>
                                    <td><?= project_status_index($val['check_index']) ?></td>
                                    <td><?php if ($val['check_index'] == 1) {
                                            echo date('H:i:s d/m/Y', $val['time_index']);
                                        } ?></td>
                                    <td><?php if ($val['status_index'] == 1) {
                                            $data_index = json_decode($val['data_index']);
                                            foreach ($data_index as  $val_index) { ?>
                                                <p><?= $val_index->name ?>: <?= $val_index->number ?>%</p>
                                        <?php }
                                        } ?>
                                    </td>
                                    <td><a href="<?= $val['file'] ?>"><?= $val['file'] ?></a></td>
                                    <td><?= number_format($val['job_price']) ?></td>
                                    <td><?php $ctv_work = fn_get_list('ctv', ['project_id' => $val['id']], 'ctv_jobs');
                                        foreach ($ctv_work as $val_work) {
                                            echo '<p>' . get_name($val_work['ctv']) . '</p>';
                                        } ?></td>
                                    <td><?= $val['note_index'] ?></td>
                                    <td><?= $val['note'] ?></td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
                <div class="list_btn_project">
                    <p class="save_project">Lưu</p>
                    <p class="reset_project">Hủy</p>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="popup_add_project">
    <div class="body_add_project">
        <div class="title_add_project">
            <p>Thêm mới dự án</p>
            <svg onclick="$('.popup_add_project').hide();" xmlns="http://www.w3.org/2000/svg" width="18" height="19" viewBox="0 0 18 19" fill="none">
                <rect y="16.25" width="22.2738" height="3.18197" rx="1.59099" transform="rotate(-45 0 16.25)" fill="white" />
                <rect x="15.75" y="18.5" width="22.2738" height="3.18197" rx="1.59098" transform="rotate(-135 15.75 18.5)" fill="white" />
            </svg>
        </div>
        <div class="main_add_project">
            <div class="this_add_project w_50">
                <p class="title_input">Khách hàng <span>*</span></p>
                <input type="text" placeholder="Nhập tên khách hàng">
            </div>
            <div class="this_add_project w_50">
                <p class="title_input">Loại dự án <span>*</span></p>
                <select name="" id="">
                    <option value="">Chọn loại dự án</option>
                </select>
            </div>
            <div class="this_add_project w_50">
                <p class="title_input">Deadline dự án <span>*</span></p>
                <input type="datetime-local">
            </div>
            <div class="this_add_project w_50">
                <p class="title_input">Doanh thu <span>*</span></p>
                <input type="text" placeholder="Nhập doanh thu">
            </div>
            <div class="this_add_project ">
                <p class="title_input">Thông tin dự án <span>*</span></p>
                <input type="text" placeholder="Nhập thông tin dự án">
            </div>
            <div class="this_add_project ">
                <p class="title_input">Website dự án <span>*</span></p>
                <input type="text" placeholder="Nhập website dự án">
            </div>
            <div class="this_add_project ">
                <p class="title_input">Ghi chú index</p>
                <input type="text" placeholder="Nhập ghi chú index">
            </div>
            <div class="this_add_project ">
                <p class="title_input">Ghi chú <span>*</span></p>
                <input type="text" placeholder="Nhập ghi chú">
            </div>
            <div class="this_add_project ">
                <p class="title_input">Index(<span>i</span>)</p>
                <div class="list_data_index">
                    <div class="data_index">
                        <input type="checkbox" name="" id="">
                        <p>Có</p>
                    </div>
                    <div class="data_index">
                        <input type="checkbox" name="" id="">
                        <p>Không</p>
                    </div>
                </div>
            </div>
            <div class="btn_add_project">
                <p>Xác Nhận</p>
            </div>
        </div>
    </div>
</div>