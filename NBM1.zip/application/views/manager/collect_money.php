<div class="main">
    <div class="main_content">
        <div class="main_top">
            <div class="add_project">
                <a href="/them-moi-thu-tien/">
                    <div class="img_add_project"><img src="/images/add_red.svg" alt="Thêm dự án"></div>
                    <p>Thêm mới thu tiền</p>
                </a>
            </div>
            <div class="right_top">
                <div class="money">
                    <p>$ 700.000</p>
                </div>
                <div class="profile">
                    <img src="/images/avatar.png" alt="avatar" class="avatar">
                    <div class="box_profile">
                        <p class="name_role">Member</p>
                        <p class="name">Ilay Riegrow <img src="/images/arrow.svg" alt="Thêm dự án"></p>
                        <div class="nav_profile">
                            <ul>
                                <li><a href="#"><img src="/images/avatar.svg" alt="Thông tin cá nhân"> Thông tin cá nhân</a></li>
                                <li><a href="#"><img src="/images/pass.svg" alt="Đổi mật khẩu"> Đổi mật khẩu</a></li>
                                <li><a href="#"><img src="/images/logout.svg" alt="Đăng xuất"> Đăng xuất</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="main_filter bg_main">
            <div class="title_filter">
                <div class="title_filter_left">
                    <img src="/images/filter.svg" alt="Bộ lọc">
                    <p>Bộ lọc</p>
                </div>
                <div class="show_filter">
                    <p>Thu gọn</p> <img src="/images/2_arrow.svg" alt="Thu gọn">
                </div>
            </div>
            <div class="list_filter">
                <div class="this_filter">
                    <input type="text" name="names" id="ids" placeholder="Mã dự án">
                </div>
                <div class="this_filter">
                    <input type="date" name="names" id="ids" placeholder="Thời gian nhận việc">
                </div>
                <div class="this_filter">
                    <input type="date" name="names" id="ids" placeholder="Thời gian tạo dự án">
                </div>
                <div class="this_filter">
                    <select name="names" id="ids">
                        <option value="0">P.I.C dự án</option>
                    </select>
                </div>
                <div class="this_filter">
                    <select name="names" id="ids">
                        <option value="0">Khách hàng</option>
                    </select>
                </div>
                <div class="this_filter">
                    <select name="names" id="ids">
                        <option value="0">Trạng thái công nợ</option>
                    </select>
                </div>
                <div class="this_filter">
                    <select name="names" id="ids">
                        <option value="0">Website dự án</option>
                    </select>
                </div>
                <div class="this_filter">
                    <select name="names" id="ids">
                        <option value="0">Trạng thái triển khai</option>
                    </select>
                </div>
                <div class="this_filter">
                    <input type="date" name="names" id="ids" placeholder="Thời gian tạo triển khai">
                </div>
                <div class="this_filter">
                    <input type="date" name="names" id="ids" placeholder="Thời gian hoàn thành">
                </div>
                <div class="this_filter">
                    <input type="date" name="names" id="ids" placeholder="Thời gian hủy">
                </div>
                <div class="this_filter">
                    <input type="date" name="names" id="ids" placeholder="Thời gian tạm dừng">
                </div>
                <div class="this_filter">
                    <select name="names" id="ids">
                        <option value="0">Trạng thái bàn giao</option>
                    </select>
                </div>
                <div class="this_filter">
                    <select name="names" id="ids">
                        <option value="0">Loại dự án</option>
                    </select>
                </div>
                <div class="this_filter">
                    <input type="date" name="names" id="ids" placeholder="Deadline dự án">
                </div>
                <div class="this_filter">
                    <select name="names" id="ids">
                        <option value="0">Tiến độ phân dự án</option>
                    </select>
                </div>
                <div class="this_filter">
                    <select name="names" id="ids">
                        <option value="0">Trạng thái công tác viên</option>
                    </select>
                </div>
                <div class="this_filter">
                    <input type="date" name="names" id="ids" placeholder="Thời gian cập nhật trạng thái CTV">
                </div>
                <div class="this_filter">
                    <select name="names" id="ids">
                        <option value="0">Trạng thái QA</option>
                    </select>
                </div>
                <div class="this_filter">
                    <input type="date" name="names" id="ids" placeholder="Thời gian cập nhật QA">
                </div>
                <div class="this_filter">
                    <select name="names" id="ids">
                        <option value="0">Trạng index</option>
                    </select>
                </div>
                <div class="this_filter">
                    <input type="date" name="names" id="ids" placeholder="Thời gian cập nhật trạng thái index">
                </div>
            </div>
        </div>
        <div class="main_filter bg_main">
            <div class="title_project">
                <div class="box_btn_project" style="display: none;">
                    <p class="btn_project btn_project_cancel">Xóa</p>
                </div>
            </div>
            <div class="box_project">
                <div class="project">
                    <table border="1" cellpadding="2" cellspacing="2">
                        <thead>
                            <tr>
                                <th rowspan="2">
                                    <div><input type="checkbox" class="check_full" name="check_full" id=""></div>
                                </th>
                                <th rowspan="2">
                                    <div>Mã dự án</div>
                                </th>
                                <th rowspan="2">
                                    <div>ID giao dịch</div>
                                </th>
                                <th rowspan="2">
                                    <div>Khách hàng</div>
                                </th>
                                <th rowspan="2">
                                    <div>Thời gian tạo</div>
                                </th>
                                <th rowspan="2">
                                    <div>Thời giao dịch</div>
                                </th>
                                <th rowspan="2">
                                    <div>Hình thức thu tiền</div>
                                </th>
                                <th rowspan="2">
                                    <div>Số tiền đã thu</div>
                                </th>
                                <th rowspan="2">
                                    <div>Trạng thái giao dịch</div>
                                </th>
                                <th colspan="3" class="th_col">Thông tin nguồn nhận</th>
                                <th colspan="3" class="th_col">Thông tin bổ sung</th>
                            </tr>
                            <tr>
                                <th>Chủ tài khoản</th>
                                <th>STK/ID USDT</th>
                                <th>Tên ngân hàng/ USDT</th>
                                <th>Nội dung chuyển khoản</th>
                                <th>Minh chứng</th>
                                <th>Ghi chú</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($collect_moneys as $val) {  ?>
                                <tr>
                                    <td><input type="checkbox" class="check_i" name="check_i" id=""></td>
                                    <td><?= project_id($val['project_id']) ?></td>
                                    <td><?= $val['bank_code'] ?></td>
                                    <td><?= $val['customer'] ?></td>
                                    <td><?= date('H:i:s d/m/Y', $val['created_at']) ?></td>
                                    <td><?= date('H:i:s d/m/Y', $val['bank_time']) ?></td>
                                    <td><?= bank_type($val['bank_type']) ?></td>
                                    <td><?= number_format($val['money']) ?></td>
                                    <td><?= bank_status($val['bank_status']) ?></td>
                                    <td><?= $val['name_input_source'] ?></td>
                                    <td><?= $val['stk'] ?></td>
                                    <td><?php $bank = fn_get_row('acronym',['id'=>$val['id_bank']],'bank');
                                    echo $bank['acronym']; ?></td>
                                    <td><?= $val['bank_content'] ?></td>
                                    <td><a href="/<?= $val['bank_image'] ?>" target="_blank" rel="noopener noreferrer" style="display: flex;gap:5px;justify-content: center;color: #2ec24f;">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="25" height="24" viewBox="0 0 25 24" fill="none">
                                                <path d="M9.5 10C10.6046 10 11.5 9.10457 11.5 8C11.5 6.89543 10.6046 6 9.5 6C8.39543 6 7.5 6.89543 7.5 8C7.5 9.10457 8.39543 10 9.5 10Z" stroke="#00B528" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                                <path d="M13.5 2H9.5C4.5 2 2.5 4 2.5 9V15C2.5 20 4.5 22 9.5 22H15.5C20.5 22 22.5 20 22.5 15V10" stroke="#00B528" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                                <path d="M18.5 8V2L20.5 4" stroke="#00B528" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                                <path d="M18.5 2L16.5 4" stroke="#00B528" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                                <path d="M3.16992 18.9501L8.09992 15.6401C8.88992 15.1101 10.0299 15.1701 10.7399 15.7801L11.0699 16.0701C11.8499 16.7401 13.1099 16.7401 13.8899 16.0701L18.0499 12.5001C18.8299 11.8301 20.0899 11.8301 20.8699 12.5001L22.4999 13.9001" stroke="#00B528" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                            </svg><?= str_replace('upload/bank_image/', '', $val['bank_image']) ?></a></td>
                                    <td><?= $val['note'] ?></td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
                <div class="list_btn_project">
                    <p class="save_project">Lưu</p>
                    <p class="reset_project">Hủy</p>
                </div>
            </div>
        </div>
    </div>
</div>