<div class="main">
    <div class="main_content">
        <div class="main_top">
            <div class="add_project">
                <div class="img_add_project"><img src="/images/add_red.svg" alt="Thêm dự án"></div>
                <p>Đề xuất thêm dự án</p>
            </div>
            <div class="right_top">
                <div class="money">
                    <p>$ 700.000</p>
                </div>
                <div class="profile">
                    <img src="/images/avatar.png" alt="avatar" class="avatar">
                    <div class="box_profile">
                        <p class="name_role">Member</p>
                        <p class="name">Ilay Riegrow <img src="/images/arrow.svg" alt="Thêm dự án"></p>
                        <div class="nav_profile">
                            <ul>
                                <li><a href="#"><img src="/images/avatar.svg" alt="Thông tin cá nhân"> Thông tin cá nhân</a></li>
                                <li><a href="#"><img src="/images/pass.svg" alt="Đổi mật khẩu"> Đổi mật khẩu</a></li>
                                <li><a href="#"><img src="/images/logout.svg" alt="Đăng xuất"> Đăng xuất</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="main_filter bg_main">
            <div class="title_filter">
                <div class="title_filter_left">
                    <img src="/images/filter.svg" alt="Bộ lọc">
                    <p>Bộ lọc</p>
                </div>
                <div class="show_filter">
                    <p>Thu gọn</p> <img src="/images/2_arrow.svg" alt="Thu gọn">
                </div>
            </div>
            <div class="list_filter">
                <div class="this_filter">
                    <select name="names" id="ids">
                        <option value="0">Nhập thông tin dự án</option>
                    </select>
                </div>
                <div class="this_filter">
                    <input type="date" name="names" id="ids" placeholder="Thời gian nhận việc">
                </div>
                <div class="this_filter">
                    <select name="names" id="ids">
                        <option value="0">Deadline CTV</option>
                    </select>
                </div>
                <div class="this_filter">
                    <input type="date" name="names" id="ids" placeholder="Thời gian hoàn thiện">
                </div>
                <div class="this_filter">
                    <select name="names" id="ids">
                        <option value="0">Loại dịch vụ</option>
                    </select>
                </div>
                <div class="this_filter">
                    <select name="names" id="ids">
                        <option value="0">Trạng thái công việc</option>
                    </select>
                </div>
                <div class="this_filter">
                    <select name="names" id="ids">
                        <option value="0">Thời gian QA duyệt</option>
                    </select>
                </div>
                <div class="this_filter">
                    <select name="names" id="ids">
                        <option value="0">Xác nhận duyệt</option>
                    </select>
                </div>
            </div>
        </div>
        <div class="main_filter bg_main">
            <div class="title_project">
                <!-- <div class="title_filter_left">
                    <img src="/images/folder.png" alt="Dự án">
                    <p>MADUAN</p>
                </div> -->
                <div class="box_btn_project" style="display: none;">
                    <p class="btn_project" onclick="$('.popup').show()">Đề xuất hủy</p>
                    <p class="btn_project btn_project_cancel">Hủy</p>
                </div>
                <!-- <img class="show_project" src="/images/add.png" alt="show" onclick="show_project(this,0)"> -->
            </div>
            <div class="box_project">
                <div class="project">
                    <table border="1" cellpadding="2" cellspacing="2">
                        <thead>
                            <tr>
                                <th rowspan="2">
                                    <div><input type="checkbox" class="check_full" name="check_full" id=""></div>
                                </th>
                                <th rowspan="2">
                                    <div>Mã dự án</div>
                                </th>
                                <th rowspan="2">
                                    <div>Deadline dự án</div>
                                </th>
                                <th rowspan="2">
                                    <div>Website dự án</div>
                                </th>
                                <th rowspan="2">
                                    <div>File dự án</div>
                                </th>
                                <th rowspan="2">
                                    <div>Thông tin dự án</div>
                                <th colspan="3" class="th_col">Index</th>
                                </th>
                                <th rowspan="2">
                                    <div>Tỉ lệ index</div>
                                </th>
                                <th rowspan="2">
                                    <div>Người duyệt index</div>
                                </th>
                                <th rowspan="2">
                                    <div>Ghi chú</div>
                                </th>
                            </tr>
                            <tr>
                                <th>Trạng thái công việc</th>
                                <th>Thời gian cập nhật</th>
                                <th>Thời gian cập nhật tiếp theo</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($project as $val) {  ?>
                                <tr>
                                    <td><input type="checkbox" class="check_i" name="check_i" id=""></td>
                                    <td><?= project_id($val['id']) ?></td>
                                    <td><?= date('H:i:s d/m/Y', $val['deadline']) ?></td>
                                    <td><?= $val['website'] ?></td>
                                    <td><?= $val['file'] ?></td>
                                    <td><?= $val['info'] ?></td>
                                    <td>
                                        <div class="status_project" data-id="<?= $val['id'] ?>">
                                            <p class="name_status"><?= project_status_index($val['check_index']) ?></p>

                                            <?php if ($val['check_index'] != 4 && $val['check_index'] != 0  && $val['check_index'] != 1) { ?>
                                                <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <mask id="path-1-inside-1_1_1465" fill="white">
                                                        <path d="M0.186279 6L5.84314 0.343141L11.5 6L5.84314 11.6569L0.186279 6Z" />
                                                    </mask>
                                                    <path d="M11.5 6L12.9142 7.41421L14.3284 6L12.9142 4.58579L11.5 6ZM4.42892 1.75735L10.0858 7.41421L12.9142 4.58579L7.25735 -1.07107L4.42892 1.75735ZM10.0858 4.58579L4.42892 10.2426L7.25735 13.0711L12.9142 7.41421L10.0858 4.58579Z" fill="black" fill-opacity="0.54" mask="url(#path-1-inside-1_1_1465)" />
                                                </svg>
                                            <?php } ?>
                                        </div>
                                        <?php if ($val['check_index'] != 4 && $val['check_index'] != 0  && $val['check_index'] != 1) { ?>
                                            <div class="arr_status">
                                                <div class="main_status">
                                                    <?php foreach (array_project_status_index() as  $val_ar) { ?>
                                                        <p data-name="status" data-id="<?= $val_ar['status'] ?>"><?= $val_ar['name'] ?></p>
                                                    <?php } ?>
                                                </div>
                                            </div>
                                        <?php } ?>
                                    </td>
                                    <td><?= ($val['time_index'] != '') ? date('H:i:s d/m/Y', $val['time_index']) : '--Thời gian cập nhật--' ?></td>
                                    <td><?= ($val['time_index_next'] != '') ? date('H:i:s d/m/Y', $val['time_index_next']) : 'Chọn ngày cập nhật' ?></td>
                                    <td><?php $data_index = json_decode($val['data_index']);
                                        foreach ($data_index as  $val_index) { ?>
                                            <p><?= $val_index->name ?>: <?= $val_index->number ?>%</p>
                                        <?php } ?>
                                    </td>
                                    <td><?php if ($val['user_check_index'] != '') {
                                            $user_check_index = explode(',', $val['user_check_index']);
                                            foreach ($user_check_index as  $val_user) { ?>
                                                <p><?= get_name($val_user) ?></p>
                                        <?php }
                                        } else {
                                            echo "--Chưa có người duyệt--";
                                        } ?>
                                    </td>
                                    <td><?= $val['note_index'] ?></td>

                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
                <div class="list_btn_project">
                    <p class="save_project">Lưu</p>
                    <p class="reset_project">Hủy</p>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="popup">
    <div class="body_popup">
        <div class="main_popup">
            <p class="title_popup">Lý do từ chối <span style="color: red;">*</span></p>
            <textarea name="" id="" style="height: 150px;"></textarea>
            <div class="btn_popup">
                <p onclick="$('.popup').hide();"><img src="/images/x.svg" alt="Đóng"> Đóng</p>
                <p class="save_popup"><img src="/images/v.svg" alt="Lưu"> Lưu</p>
            </div>
        </div>
    </div>
</div>