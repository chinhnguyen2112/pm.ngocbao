<div class="main">
    <div class="main_content">
        <div class="main_top">
            <div class="add_project">
                <div class="img_add_project"><img src="/images/add_red.svg" alt="Thêm dự án"></div>
                <p>Thêm mới loại dự án</p>
            </div>
            <div class="right_top">
                <div class="money">
                    <p>$ 700.000</p>
                </div>
                <div class="profile">
                    <img src="/images/avatar.png" alt="avatar" class="avatar">
                    <div class="box_profile">
                        <p class="name_role">Member</p>
                        <p class="name">Ilay Riegrow <img src="/images/arrow.svg" alt="Thêm dự án"></p>
                        <div class="nav_profile">
                            <ul>
                                <li><a href="#"><img src="/images/avatar.svg" alt="Thông tin cá nhân"> Thông tin cá nhân</a></li>
                                <li><a href="#"><img src="/images/pass.svg" alt="Đổi mật khẩu"> Đổi mật khẩu</a></li>
                                <li><a href="#"><img src="/images/logout.svg" alt="Đăng xuất"> Đăng xuất</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="main_filter bg_main">
            <div class="title_filter">
                <div class="title_filter_left">
                    <img src="/images/filter.svg" alt="Bộ lọc">
                    <p>Bộ lọc</p>
                </div>
                <div class="show_filter">
                    <p>Thu gọn</p> <img src="/images/2_arrow.svg" alt="Thu gọn">
                </div>
            </div>
            <div class="list_filter">
                <div class="this_filter">
                    <input type="text" name="names" id="ids" placeholder="Tên dự án">
                </div>
                <div class="this_filter">
                    <input type="datetime-local" name="names" id="ids" placeholder="Thời gian tạo">
                </div>
                <div class="this_filter">
                    <select name="names" id="ids">
                        <option value="0">Người thêm dự án</option>
                    </select>
                </div>
                <div class="this_filter">
                    <select name="names" id="ids">
                        <option value="0">Trạng thái</option>
                        <option value="1">Đang hoạt động</option>
                        <option value="2">Tạm dừng hoạt động</option>
                    </select>
                </div>
            </div>
        </div>
        <div class="main_filter bg_main">
            <div class="title_project">
                <div class="box_btn_project" style="display: none;">
                    <p class="btn_project" onclick="$('.popup').show()">Xóa</p>
                    <p class="btn_project btn_project_cancel">Hủy</p>
                </div>
            </div>
            <div class="box_project">
                <div class="project">
                    <table border="1" cellpadding="2" cellspacing="2">
                        <thead>
                            <tr>
                                <th rowspan="2">
                                    <div><input type="checkbox" class="check_full" name="check_full" id=""></div>
                                </th>
                                <th rowspan="2">
                                    <div>Tên loại dự án</div>
                                </th>
                                <th rowspan="2">
                                    <div>Thời gian thêm</div>
                                </th>
                                <th rowspan="2">
                                    <div>Người thêm</div>
                                </th>
                                <th rowspan="2">
                                    <div>Trạng thái</div>
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($list as $val) {  ?>
                                <tr>
                                    <td><input type="checkbox" class="check_i" name="check_i" id=""></td>
                                    <td class="edit_text" ondblclick="edit_text(this,'name',<?= $val['id'] ?>);"><?= $val['name'] ?></td>
                                    <td><?= date('H:i:s', $val['created_at']) ?><br><?= date('d/m/Y', $val['created_at']) ?></td>
                                    <td><?= $val['name_author'] ?></td>
                                    <td class="edit_option" ondblclick="edit_option(this);">
                                        <div class="status_project" data-id="<?= $val['id'] ?>">
                                            <p data-val="1" <?= ($val['status'] == 2) ? ' onclick="change_option(this,`status`)"' : '' ?> class="<?= ($val['status'] == 1) ? 'active' : '' ?>">Đang hoạt động</p>
                                            <p data-val="2" <?= ($val['status'] == 1) ? ' onclick="change_option(this,`status`)"' : '' ?> class="<?= ($val['status'] == 2) ? 'active' : '' ?>" style="color:#FF7A00;">Tạm dừng hoạt động</p>
                                            <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <mask id="path-1-inside-1_1_1465" fill="white">
                                                    <path d="M0.186279 6L5.84314 0.343141L11.5 6L5.84314 11.6569L0.186279 6Z" />
                                                </mask>
                                                <path d="M11.5 6L12.9142 7.41421L14.3284 6L12.9142 4.58579L11.5 6ZM4.42892 1.75735L10.0858 7.41421L12.9142 4.58579L7.25735 -1.07107L4.42892 1.75735ZM10.0858 4.58579L4.42892 10.2426L7.25735 13.0711L12.9142 7.41421L10.0858 4.58579Z" fill="black" fill-opacity="0.54" mask="url(#path-1-inside-1_1_1465)" />
                                            </svg>
                                        </div>
                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
                <div class="list_btn_project">
                    <p class="save_project">Lưu</p>
                    <p class="reset_project">Hủy</p>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="popup_add_project">
    <div class="body_add_project">
        <div class="title_add_project">
            <p>Thêm mới loại dự án</p>
            <svg onclick="$('.popup_add_project').hide();" xmlns="http://www.w3.org/2000/svg" width="18" height="19" viewBox="0 0 18 19" fill="none">
                <rect y="16.25" width="22.2738" height="3.18197" rx="1.59099" transform="rotate(-45 0 16.25)" fill="white" />
                <rect x="15.75" y="18.5" width="22.2738" height="3.18197" rx="1.59098" transform="rotate(-135 15.75 18.5)" fill="white" />
            </svg>
        </div>
        <form id="form_add">
            <div class="main_add_project">
                <div class="this_add_project">
                    <p class="title_input">Tên dự án <span>*</span></p>
                    <input type="text" name="name" id="name" placeholder="Nhập">
                </div>
                <div class="this_add_project">
                    <p class="title_input">Trạng thái <span>*</span></p>
                    <select name="status" id="status">
                        <option value="">Chọn trạng thái</option>
                        <option value="1">Đang hoạt động</option>
                        <option value="2">Tạm dừng hoạt động</option>
                    </select>
                </div>
                <button class="btn_add_project">
                    <p>Xác Nhận</p>
                </button>
            </div>
        </form>
    </div>
</div>